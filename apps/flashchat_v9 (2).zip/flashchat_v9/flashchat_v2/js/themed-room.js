// ── THEMED ROOM: SVG canvas overlay + MultiAvatarEngine + position sync ──
import {
  db, doc, getDoc, setDoc, collection, onSnapshot, serverTimestamp,
} from './config.js';
import { state } from './state.js';
import { MultiAvatarEngine } from './avatar-engine.js';

let _engine        = null;
let _posUnsub      = null;
let _heartbeatId   = null;
let _container     = null;
let _currentRoomDocId = null;
let _currentThemedDocId = null;

function buildOverlay(canvasW, canvasH, themedData) {
  const wrap = document.getElementById('messages-wrap');
  if (!wrap) return null;

  // Container overlay — duduk di atas messages-wrap, transparan
  const container = document.createElement('div');
  container.className = 'themed-room-overlay';
  container.id = 'themed-room-overlay';

  // SVG canvas
  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${canvasW} ${canvasH}`);
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  svg.classList.add('themed-canvas');

  // Background warna (opsional dari themedData.bg)
  const bgColor = themedData.bg || themedData.background || '#0f1020';
  const bgRect = document.createElementNS(svgNS, 'rect');
  bgRect.setAttribute('x', '0');
  bgRect.setAttribute('y', '0');
  bgRect.setAttribute('width', canvasW);
  bgRect.setAttribute('height', canvasH);
  bgRect.setAttribute('fill', bgColor);
  svg.appendChild(bgRect);

  // Static layer: blocks + portals
  const staticG = document.createElementNS(svgNS, 'g');
  staticG.setAttribute('id', 'themed-static');
  (themedData.blocks || []).forEach(b => {
    const r = document.createElementNS(svgNS, 'rect');
    r.setAttribute('x', b.x); r.setAttribute('y', b.y);
    r.setAttribute('width', b.w); r.setAttribute('height', b.h);
    r.setAttribute('fill', b.fill || '#3a3a52');
    r.setAttribute('stroke', b.stroke || 'rgba(255,255,255,0.08)');
    r.setAttribute('rx', '4');
    staticG.appendChild(r);
  });
  (themedData.portals || []).forEach(p => {
    const r = document.createElementNS(svgNS, 'rect');
    r.setAttribute('x', p.x); r.setAttribute('y', p.y);
    r.setAttribute('width', p.w); r.setAttribute('height', p.h);
    r.setAttribute('fill', p.fill || 'rgba(167,139,250,0.25)');
    r.setAttribute('stroke', '#a78bfa');
    r.setAttribute('stroke-dasharray', '4 3');
    r.setAttribute('rx', '6');
    staticG.appendChild(r);
    if (p.label) {
      const t = document.createElementNS(svgNS, 'text');
      t.setAttribute('x', p.x + p.w / 2);
      t.setAttribute('y', p.y + p.h / 2 + 3);
      t.setAttribute('text-anchor', 'middle');
      t.setAttribute('font-size', '9');
      t.setAttribute('font-family', 'DM Sans, sans-serif');
      t.setAttribute('fill', '#fff');
      t.textContent = p.label;
      staticG.appendChild(t);
    }
  });
  svg.appendChild(staticG);
  container.appendChild(svg);

  // Joystick
  const joy = document.createElement('div');
  joy.className = 'themed-joystick';
  joy.innerHTML = '<div class="themed-joystick-stick"></div>';
  container.appendChild(joy);

  wrap.appendChild(container);
  return { container, svg, joystick: joy };
}

function attachJoystick(joyEl, engine) {
  const stick = joyEl.querySelector('.themed-joystick-stick');
  const radius = 36;
  let active = false;
  let cx = 0, cy = 0;

  const setVec = (dx, dy) => {
    const mag = Math.hypot(dx, dy);
    if (mag > radius) { dx = dx / mag * radius; dy = dy / mag * radius; }
    stick.style.transform = `translate(${dx}px, ${dy}px)`;
    engine.setJoystickVector(dx / radius, dy / radius);
  };

  const onDown = (e) => {
    active = true;
    const t = e.touches ? e.touches[0] : e;
    const r = joyEl.getBoundingClientRect();
    cx = r.left + r.width / 2;
    cy = r.top + r.height / 2;
    setVec(t.clientX - cx, t.clientY - cy);
    e.preventDefault();
  };
  const onMove = (e) => {
    if (!active) return;
    const t = e.touches ? e.touches[0] : e;
    setVec(t.clientX - cx, t.clientY - cy);
  };
  const onUp = () => {
    if (!active) return;
    active = false;
    stick.style.transform = '';
    engine.setJoystickVector(0, 0);
  };

  joyEl.addEventListener('mousedown', onDown);
  joyEl.addEventListener('touchstart', onDown, { passive: false });
  window.addEventListener('mousemove', onMove);
  window.addEventListener('touchmove', onMove, { passive: false });
  window.addEventListener('mouseup', onUp);
  window.addEventListener('touchend', onUp);

  // Save handlers for cleanup
  joyEl._cleanup = () => {
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('touchmove', onMove);
    window.removeEventListener('mouseup', onUp);
    window.removeEventListener('touchend', onUp);
  };
}

async function publishLocalPosition(x, y, face, isMoving) {
  if (!_currentThemedDocId || !state.currentUser) return;
  try {
    await setDoc(
      doc(db, 'fc_themed_rooms', _currentThemedDocId, 'fc_avatar_positions', state.currentUser.uid),
      {
        x, y, face, isMoving,
        uid:         state.currentUser.uid,
        name:        state.currentUser.displayName || 'Pengguna',
        photoURL:    state.currentUser.photoURL || null,
        t:           serverTimestamp(),
      },
      { merge: true }
    );
  } catch (e) { /* silent (offline / quota) */ }
}

function subscribePositions(themedDocId, canvasW, canvasH) {
  if (_posUnsub) _posUnsub();
  const col = collection(db, 'fc_themed_rooms', themedDocId, 'fc_avatar_positions');
  _posUnsub = onSnapshot(col, snap => {
    if (!_engine) return;
    const now = Date.now();
    snap.forEach(d => {
      if (d.id === state.currentUser.uid) return;
      const data = d.data();
      const t = data.t?.toMillis?.() || 0;
      if (now - t > 30000) { _engine.updateRemote(d.id, null); return; }
      _engine.updateRemote(d.id, {
        x:        data.x        ?? canvasW / 2,
        y:        data.y        ?? canvasH / 2,
        face:     data.face     ?? 1,
        isMoving: data.isMoving ?? false,
        name:     data.name     || 'User',
        photoURL: data.photoURL || null,
      });
    });
    snap.docChanges().forEach(ch => {
      if (ch.type === 'removed') _engine.updateRemote(ch.doc.id, null);
    });
  }, () => {});
}

export async function openThemedRoom(room) {
  // Clean up any previous themed session
  closeThemedRoom();

  _currentRoomDocId = room.id;
  _currentThemedDocId = room.themedRoomId;
  if (!_currentThemedDocId) return;

  let themedData;
  try {
    const snap = await getDoc(doc(db, 'fc_themed_rooms', _currentThemedDocId));
    if (!snap.exists()) return;
    themedData = snap.data();
  } catch (e) { return; }

  const canvasW = themedData.canvasW || 400;
  const canvasH = themedData.canvasH || 600;

  const built = buildOverlay(canvasW, canvasH, themedData);
  if (!built) return;
  _container = built.container;

  _engine = new MultiAvatarEngine({
    svgEl:      built.svg,
    canvasW, canvasH,
    getBlocks:  () => themedData.blocks  || [],
    getPortals: () => themedData.portals || [],
    onPortal:   () => {},
    localUid:   state.currentUser.uid,
    localName:  state.currentUser.displayName || 'Anda',
    localPhoto: state.currentUser.photoURL || null,
    onPositionChange: publishLocalPosition,
  });
  _engine.start();

  attachJoystick(built.joystick, _engine);
  subscribePositions(_currentThemedDocId, canvasW, canvasH);

  // Heartbeat agar entri tetap "hidup" walau diam
  _heartbeatId = setInterval(() => {
    if (!_engine) return;
    const p = _engine.getLocalPosition();
    publishLocalPosition(p.x, p.y, 1, false);
  }, 15000);

  state.themedRoomActive = true;
}

export function closeThemedRoom() {
  if (_engine)       { _engine.destroy(); _engine = null; }
  if (_posUnsub)     { _posUnsub();       _posUnsub = null; }
  if (_heartbeatId)  { clearInterval(_heartbeatId); _heartbeatId = null; }
  if (_container)    {
    const joy = _container.querySelector('.themed-joystick');
    if (joy && joy._cleanup) joy._cleanup();
    _container.remove();
    _container = null;
  }
  _currentRoomDocId = null;
  _currentThemedDocId = null;
  state.themedRoomActive = false;
}
