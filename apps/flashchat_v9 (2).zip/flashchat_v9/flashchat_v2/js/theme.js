// ── LIGHT / DARK THEME ──

export function toggleTheme(checkbox) {
  const theme = checkbox.checked ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', theme);
  try { localStorage.setItem('fc_theme', theme); } catch (e) {}
}

export function restoreTheme() {
  try {
    const saved = localStorage.getItem('fc_theme');
    if (saved) {
      document.documentElement.setAttribute('data-theme', saved);
      const toggle = document.getElementById('theme-toggle');
      if (toggle) toggle.checked = (saved !== 'light');
    } else {
      const toggle = document.getElementById('theme-toggle');
      if (toggle) toggle.checked = true;
    }
  } catch (e) {}
}

export function syncThemeToggle() {
  try {
    const saved = localStorage.getItem('fc_theme');
    const toggle = document.getElementById('theme-toggle');
    if (toggle) toggle.checked = (saved !== 'light');
  } catch (e) {}
}
