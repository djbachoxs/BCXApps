// ── ROOMS: LIST, OPEN, CREATE ──
import {
  db, collection, doc, addDoc, deleteDoc, getDocs,
  onSnapshot, query, where, serverTimestamp, getDoc,
} from './config.js';
import { state } from './state.js';
import { showToast } from './utils.js';
import { openModal, closeModal } from './ui.js';
import { listenMessages } from './messages.js';
import { listenPresence, listenTyping } from './presence.js';
import { openThemedRoom, closeThemedRoom } from './themed-room.js';

export function listenRooms() {
  if (state.roomsUnsub) state.roomsUnsub();
  const q = collection(db, 'fc_rooms');
  state.roomsUnsub = onSnapshot(q, snap => {
    const roomList   = document.getElementById('room-list');
    roomList.innerHTML = '';
    let firstPublic  = null;

    const docs = []; snap.forEach(d => docs.push(d));
    const PINNED = ['alun-alun', 'aula'];
    docs.sort((a, b) => {
      const an = (a.data().name || '').toLowerCase();
      const bn = (b.data().name || '').toLowerCase();
      const ai = PINNED.indexOf(an); const bi = PINNED.indexOf(bn);
      if (ai !== -1 || bi !== -1) {
        if (ai === -1) return 1;
        if (bi === -1) return -1;
        return ai - bi;
      }
      return 0;
    });

    docs.forEach(d => {
      const room = { id: d.id, ...d.data() };
      if (room.type === 'private') {
        const members = room.members || [];
        if (!members.includes(state.currentUser.uid)) return;
      }
      if (!firstPublic && room.type === 'public') firstPublic = room;

      const wrap   = document.createElement('div');
      wrap.className = 'room-item-wrap';

      const roomEl = document.createElement('div');
      roomEl.className = `room-item${state.currentRoomId === d.id ? ' active' : ''}`;
      roomEl.dataset.roomId = d.id;
      roomEl.innerHTML = `
        <span class="room-icon">${room.type === 'private' ? '🔒' : '#'}</span>
        <span class="room-name">${room.name}</span>`;
      roomEl.onclick = () => { openRoom(room); };
      wrap.appendChild(roomEl);

      // Settings button for custom rooms (non-system, user is member or creator)
      if (room.createdBy !== 'system') {
        const settingsBtn     = document.createElement('div');
        settingsBtn.className = 'room-settings-btn';
        settingsBtn.title     = 'Pengaturan room';
        settingsBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
        settingsBtn.onclick   = async (e) => {
          e.stopPropagation();
          // Make sure the room is loaded as current before opening modal
          if (state.currentRoomId !== room.id) {
            await openRoom(room);
          }
          const { openMembersModal } = await import('./members.js');
          openMembersModal();
        };
        wrap.appendChild(settingsBtn);
      }

      // Delete button (creator only, non-system)
      if (room.createdBy === state.currentUser.uid && room.createdBy !== 'system') {
        const delBtn      = document.createElement('div');
        delBtn.className  = 'room-delete-btn';
        delBtn.title      = 'Hapus room';
        delBtn.innerHTML  = `<i data-lucide="x"></i>`;
        delBtn.onclick    = (e) => {
          e.stopPropagation();
          openDeleteConfirm(room);
        };
        wrap.appendChild(delBtn);
      }

      roomList.appendChild(wrap);
    });

    if (!state.currentRoomId && firstPublic) openRoom(firstPublic);
    lucide.createIcons();
    listenPresence();
  });
}

export async function openRoom(room) {
  if (state.currentRoomId && state.currentRoomId !== room.id) {
    const { clearTyping } = await import('./presence.js');
    clearTyping();
  }

  // Selalu bersihkan sesi themed sebelumnya (kalau ada)
  closeThemedRoom();

  state.currentRoomId   = room.id;
  state.currentRoomData = room;

  // Fetch latest room data (nameTheme, isThemed, themedRoomId, dll.)
  try {
    const snap = await getDoc(doc(db, 'fc_rooms', room.id));
    if (snap.exists()) state.currentRoomData = { id: snap.id, ...snap.data() };
  } catch (e) {}

  const rd = state.currentRoomData;
  document.getElementById('header-room-name').textContent =
    (rd.type === 'private' ? '🔒 ' : '# ') + rd.name + (rd.isThemed ? ' ✨' : '');

  document.querySelectorAll('.room-item').forEach(el => {
    el.classList.toggle('active', el.dataset.roomId === room.id);
  });

  listenTyping(room.id);
  listenMessages(room.id);

  // Cabang khusus room tematik: render canvas + avatar engine
  if (rd.isThemed && rd.themedRoomId) {
    try { await openThemedRoom(rd); } catch (e) { console.error('[themed-room]', e); }
  }
}

// ── Create Room ──
export async function openCreateRoom() {
  document.getElementById('new-room-name').value = '';
  document.getElementById('create-room-error').classList.remove('show');

  // Reset toggle ke "Room Biasa"
  document.getElementById('room-kind-regular').checked = true;
  document.getElementById('themed-room-select-group').style.display = 'none';
  document.getElementById('themed-room-name-display-group').style.display = 'none';
  document.getElementById('new-room-name').closest('.input-group').style.display = '';

  const q     = query(collection(db, 'fc_rooms'), where('createdBy', '==', state.currentUser.uid));
  const snap  = await getDocs(q);
  const count = snap.size;
  const isFull = count >= 4;

  const countEl = document.getElementById('quota-count');
  const fillEl  = document.getElementById('quota-fill');
  countEl.textContent = `${count} / 4`;
  countEl.classList.toggle('full', isFull);
  fillEl.style.width = `${Math.min((count / 4) * 100, 100)}%`;
  fillEl.classList.toggle('full', isFull);

  const btn        = document.getElementById('btn-do-create-room');
  const nameInput  = document.getElementById('new-room-name');
  const typeSelect = document.getElementById('new-room-type');
  btn.disabled        = isFull;
  nameInput.disabled  = isFull;
  typeSelect.disabled = isFull;

  if (isFull) {
    const errEl = document.getElementById('create-room-error');
    errEl.textContent = 'Kamu sudah membuat 4 room (batas maksimum). Hapus room lama untuk membuat yang baru.';
    errEl.classList.add('show');
  } else {
    document.getElementById('create-room-error').classList.remove('show');
  }

  // Fetch themed rooms dari Firestore
  try {
    const themedSnap   = await getDocs(collection(db, 'fc_themed_rooms'));
    const themedSelect = document.getElementById('themed-room-select');
    themedSelect.innerHTML = '<option value="" disabled selected>Pilih desain tematik...</option>';
    themedSnap.forEach(d => {
      const data   = d.data();
      const label  = (data.name || '(tanpa nama)') + ' — ' + (data.nameTheme || '');
      const option = document.createElement('option');
      option.value       = d.id;
      option.textContent = label;
      themedSelect.appendChild(option);
    });
    if (themedSnap.empty) {
      const option = document.createElement('option');
      option.value = '';
      option.disabled = true;
      option.textContent = 'Belum ada desain tematik tersedia';
      themedSelect.appendChild(option);
    }
  } catch (e) {
    const themedSelect = document.getElementById('themed-room-select');
    themedSelect.innerHTML = '<option value="" disabled selected>Gagal memuat desain</option>';
  }

  // Update nama display saat pilihan themed berubah
  const themedSelect = document.getElementById('themed-room-select');
  themedSelect.onchange = () => {
    const selected = themedSelect.options[themedSelect.selectedIndex];
    document.getElementById('themed-room-name-display').textContent =
      selected && selected.value ? selected.textContent.split(' — ')[0] : '—';
  };

  // Toggle antara Room Biasa dan Room Tematik
  document.querySelectorAll('input[name="room-kind"]').forEach(radio => {
    radio.onchange = () => {
      const isThemed = document.getElementById('room-kind-themed').checked;
      document.getElementById('themed-room-select-group').style.display       = isThemed ? '' : 'none';
      document.getElementById('themed-room-name-display-group').style.display = isThemed ? '' : 'none';
      document.getElementById('new-room-name').closest('.input-group').style.display = isThemed ? 'none' : '';
      // Disable input nama room saat tematik agar tidak ikut validasi
      document.getElementById('new-room-name').disabled = isThemed || isFull;
    };
  });

  openModal('modal-create-room');
  lucide.createIcons();
}

export function initCreateRoomListener() {
  document.getElementById('btn-do-create-room').onclick = async () => {
    const type  = document.getElementById('new-room-type').value;
    const errEl = document.getElementById('create-room-error');
    errEl.classList.remove('show');

    const isThemed = document.getElementById('room-kind-themed').checked;

    if (!isThemed) {
      // ── Mode Room Biasa: perilaku tidak berubah ──
      const name = document.getElementById('new-room-name').value.trim();
      if (!name) {
        errEl.textContent = 'Nama room wajib diisi.';
        errEl.classList.add('show');
        return;
      }

      // Double-check quota
      const qCheck    = query(collection(db, 'fc_rooms'), where('createdBy', '==', state.currentUser.uid));
      const snapCheck = await getDocs(qCheck);
      if (snapCheck.size >= 4) {
        errEl.textContent = 'Batas 4 room tercapai. Hapus room lama terlebih dahulu.';
        errEl.classList.add('show');
        return;
      }

      document.getElementById('btn-do-create-room').disabled = true;
      try {
        await addDoc(collection(db, 'fc_rooms'), {
          name, type,
          createdBy: state.currentUser.uid,
          members: [state.currentUser.uid],
          createdAt: serverTimestamp(),
        });
        closeModal('modal-create-room');
        showToast(`Room "${name}" berhasil dibuat! 🎉`);
      } catch (e) {
        errEl.textContent = 'Gagal membuat room.';
        errEl.classList.add('show');
      }
      document.getElementById('btn-do-create-room').disabled = false;

    } else {
      // ── Mode Room Tematik ──
      const themedSelect = document.getElementById('themed-room-select');
      const docId        = themedSelect.value;

      if (!docId) {
        errEl.textContent = 'Pilih desain tematik terlebih dahulu.';
        errEl.classList.add('show');
        return;
      }

      // Double-check quota
      const qCheck    = query(collection(db, 'fc_rooms'), where('createdBy', '==', state.currentUser.uid));
      const snapCheck = await getDocs(qCheck);
      if (snapCheck.size >= 4) {
        errEl.textContent = 'Batas 4 room tercapai. Hapus room lama terlebih dahulu.';
        errEl.classList.add('show');
        return;
      }

      document.getElementById('btn-do-create-room').disabled = true;
      try {
        const themedDocRef  = doc(db, 'fc_themed_rooms', docId);
        const themedDocSnap = await getDoc(themedDocRef);

        if (!themedDocSnap.exists()) {
          errEl.textContent = 'Desain tematik tidak ditemukan.';
          errEl.classList.add('show');
          document.getElementById('btn-do-create-room').disabled = false;
          return;
        }

        const themedDoc = themedDocSnap.data();
        const roomName  = themedDoc.name || 'Room Tematik';

        await addDoc(collection(db, 'fc_rooms'), {
          name:        roomName,
          type:        type,
          themedRoomId: docId,
          isThemed:    true,
          createdBy:   state.currentUser.uid,
          members:     [state.currentUser.uid],
          createdAt:   serverTimestamp(),
        });
        closeModal('modal-create-room');
        showToast(`Room tematik "${roomName}" berhasil dibuat! ✨`);
      } catch (e) {
        errEl.textContent = 'Gagal membuat room tematik.';
        errEl.classList.add('show');
      }
      document.getElementById('btn-do-create-room').disabled = false;
    }
  };
}

// ── Delete Room Confirmation Modal ──
function openDeleteConfirm(room) {
  const msgEl = document.getElementById('modal-confirm-delete-msg');
  msgEl.textContent = `Yakin ingin menghapus room "${room.name}"?`;

  openModal('modal-confirm-delete');
  lucide.createIcons();

  const btn = document.getElementById('btn-confirm-delete-room');
  // Remove previous listeners by cloning
  const newBtn = btn.cloneNode(true);
  btn.parentNode.replaceChild(newBtn, btn);

  newBtn.onclick = async () => {
    newBtn.disabled = true;
    try {
      const msgSnap = await getDocs(collection(db, 'fc_rooms', room.id, 'messages'));
      for (const md of msgSnap.docs) await deleteDoc(md.ref).catch(() => {});
      await deleteDoc(doc(db, 'fc_rooms', room.id));
      if (state.currentRoomId === room.id) {
        state.currentRoomId   = null;
        state.currentRoomData = null;
      }
      closeDeleteConfirm();
      showToast(`Room "${room.name}" dihapus.`);
    } catch (err) {
      showToast('Gagal menghapus room.');
      newBtn.disabled = false;
    }
  };
}

function closeDeleteConfirm() {
  closeModal('modal-confirm-delete');
}

// Expose globally for inline onclick in HTML
window.closeDeleteConfirm = closeDeleteConfirm;
