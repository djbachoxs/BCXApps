/**
 * avatar-engine.js  —  v2  (multi-avatar + Firebase presence)
 * ─────────────────────────────────────────────────────────────────────────────
 * FlashChat — Themed Room Avatar Engine
 *
 * v2 menambahkan:
 *   • MultiAvatarEngine  — mengelola banyak avatar sekaligus (live users dari Firebase)
 *   • LocalAvatar        — avatar yang dikontrol user lokal (joystick)
 *   • RemoteAvatar       — avatar pengguna lain (posisi diinterpolasi dari Firestore)
 *   • Warna avatar unik per uid (deterministik, tidak random setiap render)
 *   • Support photoURL (avatar foto bulat) atau fallback inisial warna
 *
 * AvatarEngine (v1 — single avatar, backward-compatible) tetap tersedia.
 * ─────────────────────────────────────────────────────────────────────────────
 */

// ── Konstanta fisika ──────────────────────────────────────────────
const AVATAR_RADIUS    = 12;
const SPEED            = 140;
const FRICTION         = 0.80;
const PORTAL_COOLDOWN  = 1200;
const BLINK_INTERVAL   = 3200;
const BLINK_DURATION   = 180;
const REMOTE_LERP      = 0.14;  // interpolasi posisi avatar remote (0..1)

// ── Palet warna avatar (per-uid) ─────────────────────────────────
const AVATAR_PALETTE = [
  { body:'#2563eb', rim:'#1d4ed8', label:'#1e3a8a' },
  { body:'#16a34a', rim:'#15803d', label:'#14532d' },
  { body:'#dc2626', rim:'#b91c1c', label:'#7f1d1d' },
  { body:'#7c3aed', rim:'#6d28d9', label:'#4c1d95' },
  { body:'#d97706', rim:'#b45309', label:'#78350f' },
  { body:'#0891b2', rim:'#0e7490', label:'#164e63' },
  { body:'#be185d', rim:'#9d174d', label:'#500724' },
  { body:'#4f46e5', rim:'#4338ca', label:'#312e81' },
];

function colorForUid(uid) {
  if (!uid) return AVATAR_PALETTE[0];
  let h = 0;
  for (let i = 0; i < uid.length; i++) h = (h * 31 + uid.charCodeAt(i)) >>> 0;
  return AVATAR_PALETTE[h % AVATAR_PALETTE.length];
}

// SVG NS helper
const NS = 'http://www.w3.org/2000/svg';
function svgEl(tag, attrs = {}) {
  const e = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  return e;
}

// ── Geometri ──────────────────────────────────────────────────────
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

function circleVsAABB(cx, cy, r, rx, ry, rw, rh) {
  const nearX = clamp(cx, rx, rx + rw);
  const nearY = clamp(cy, ry, ry + rh);
  const dx = cx - nearX, dy = cy - nearY;
  const dist = Math.sqrt(dx * dx + dy * dy);
  if (dist >= r || dist === 0) return null;
  const pen = r - dist;
  return { nx: dx / dist, ny: dy / dist, pen };
}

function pointInRect(px, py, rx, ry, rw, rh, margin = 0) {
  return px >= rx - margin && px <= rx + rw + margin &&
         py >= ry - margin && py <= ry + rh + margin;
}

// ── Initials helper ───────────────────────────────────────────────
function initials(name) {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0][0].toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

// ══════════════════════════════════════════════════════════════════
// AvatarRenderer — menggambar satu avatar ke dalam SVG <g>
// Dipakai oleh AvatarEngine (single) dan MultiAvatarEngine (multi)
// ══════════════════════════════════════════════════════════════════
class AvatarRenderer {
  constructor(svgContainer, opts = {}) {
    this._svg    = svgContainer;
    this._name   = opts.name   || 'User';
    this._uid    = opts.uid    || '';
    this._photo  = opts.photo  || null;   // URL foto profil
    this._color  = opts.color  || colorForUid(this._uid);

    this._x = opts.x || 200;
    this._y = opts.y || 300;
    this._face = 1;
    this._isMoving = false;
    this._blinking = false;
    this._blinkAt  = Date.now() + BLINK_INTERVAL + Math.random() * 2000;
    this._flashAlpha = 0;
    this._inFlash    = false;
    this._particles  = [];
    this._lastParticle = 0;

    this._group = svgEl('g', { 'pointer-events': 'none' });
    this._build();
    this._svg.appendChild(this._group);
  }

  destroy() {
    if (this._group.parentNode) this._group.parentNode.removeChild(this._group);
  }

  setPosition(x, y, face, isMoving) {
    this._x = x; this._y = y;
    this._face = face; this._isMoving = isMoving;
  }

  triggerPortalFlash() {
    this._inFlash = true;
    this._flashAlpha = 1;
  }

  stepFlash(dt) {
    if (!this._inFlash) return;
    this._flashAlpha = Math.max(0, this._flashAlpha - dt * 2.5);
    if (this._flashAlpha <= 0) this._inFlash = false;
  }

  stepBlink(now) {
    if (!this._blinking && now >= this._blinkAt) {
      this._blinking = true;
      setTimeout(() => {
        this._blinking = false;
        this._blinkAt  = Date.now() + BLINK_INTERVAL + Math.random() * 1500;
      }, BLINK_DURATION);
    }
  }

  render(now) {
    const x = this._x, y = this._y;
    const R = AVATAR_RADIUS;
    const f = this._face;

    this._shadowEl.setAttribute('cx', x);
    this._shadowEl.setAttribute('cy', y + R + 1);

    this._glowEl.setAttribute('cx', x);
    this._glowEl.setAttribute('cy', y);
    this._glowEl.setAttribute('opacity', String(this._flashAlpha * 0.8));

    const bounce = this._isMoving ? 1 + 0.06 * Math.sin(now / 80) : 1;
    this._bodyEl.setAttribute('cx', x);
    this._bodyEl.setAttribute('cy', y);
    this._bodyEl.setAttribute('transform',
      `translate(${x},${y}) scale(${1/bounce},${bounce}) translate(${-x},${-y})`);

    if (this._photoClip) {
      // photo avatar
      this._photoImg.setAttribute('x', x - R);
      this._photoImg.setAttribute('y', y - R);
      this._photoClip.querySelector('circle').setAttribute('cx', x);
      this._photoClip.querySelector('circle').setAttribute('cy', y);
    } else {
      // initials face
      const faceOffX = f * 2;
      const eyeOffY  = -2;
      const eyeSep   = 3.5;
      const lookX    = this._isMoving ? f * 0.7 : 0;
      const lidRy    = this._blinking ? '3.2' : '0';

      this._eyeLW.setAttribute('cx', x + faceOffX - eyeSep);
      this._eyeLW.setAttribute('cy', y + eyeOffY);
      this._eyeRW.setAttribute('cx', x + faceOffX + eyeSep);
      this._eyeRW.setAttribute('cy', y + eyeOffY);
      this._eyeLP.setAttribute('cx', x + faceOffX - eyeSep + lookX);
      this._eyeLP.setAttribute('cy', y + eyeOffY + 0.6);
      this._eyeRP.setAttribute('cx', x + faceOffX + eyeSep + lookX);
      this._eyeRP.setAttribute('cy', y + eyeOffY + 0.6);
      this._lidL.setAttribute('cx', x + faceOffX - eyeSep);
      this._lidL.setAttribute('cy', y + eyeOffY);
      this._lidL.setAttribute('ry', lidRy);
      this._lidR.setAttribute('cx', x + faceOffX + eyeSep);
      this._lidR.setAttribute('cy', y + eyeOffY);
      this._lidR.setAttribute('ry', lidRy);
      this._blushL.setAttribute('cx', x + faceOffX - eyeSep - 1);
      this._blushL.setAttribute('cy', y + 1.5);
      this._blushR.setAttribute('cx', x + faceOffX + eyeSep + 1);
      this._blushR.setAttribute('cy', y + 1.5);

      if (this._initialsEl) {
        this._initialsEl.setAttribute('x', x);
        this._initialsEl.setAttribute('y', y + 5.5);
      }
    }

    this._labelEl.setAttribute('x', x);
    this._labelEl.setAttribute('y', y - R - 4);

    if (this._isMoving) this._spawnParticle(x, y + R, now);
    this._updateParticles(now);
  }

  _build() {
    const g = this._group;
    const c = this._color;
    const R = AVATAR_RADIUS;

    this._shadowEl = svgEl('ellipse', {
      rx: R * 1.1, ry: R * 0.38,
      fill: 'rgba(0,0,0,0.18)', opacity: '0.7',
    });
    g.appendChild(this._shadowEl);

    this._glowEl = svgEl('circle', {
      r: R + 8, fill: 'none', stroke: '#a78bfa',
      'stroke-width': '3', opacity: '0',
    });
    g.appendChild(this._glowEl);

    this._bodyEl = svgEl('circle', {
      r: R, fill: c.body,
      stroke: c.rim, 'stroke-width': '1.5',
    });
    g.appendChild(this._bodyEl);

    if (this._photo) {
      this._buildPhotoFace(R, c);
    } else {
      this._buildInitialsFace(R, c);
    }

    // Name label with background pill
    const labelGroup = svgEl('g', { 'pointer-events': 'none' });
    this._labelBg = svgEl('rect', {
      fill: 'rgba(255,255,255,0.85)', rx: '4',
      'stroke': 'rgba(0,0,0,0.06)', 'stroke-width': '0.5',
    });
    this._labelEl = svgEl('text', {
      'text-anchor': 'middle', 'dominant-baseline': 'auto',
      'font-size': '8', 'font-family': 'DM Sans,sans-serif',
      'font-weight': '600', fill: c.label, opacity: '1',
    });
    this._labelEl.textContent = this._name;
    labelGroup.appendChild(this._labelBg);
    labelGroup.appendChild(this._labelEl);
    g.appendChild(labelGroup);
    this._labelGroup = labelGroup;

    this._particleG = svgEl('g');
    g.appendChild(this._particleG);
  }

  _buildPhotoFace(R, c) {
    const g = this._group;
    const clipId = 'avatar-clip-' + (this._uid || Math.random().toString(36).slice(2));

    const defs = svgEl('defs');
    const clip = svgEl('clipPath', { id: clipId });
    const clipCircle = svgEl('circle', { r: R - 1, cx: this._x, cy: this._y });
    clip.appendChild(clipCircle);
    defs.appendChild(clip);
    g.appendChild(defs);
    this._photoClip = clip;

    const img = svgEl('image', {
      href:   this._photo,
      width:  (R * 2).toString(),
      height: (R * 2).toString(),
      preserveAspectRatio: 'xMidYMid slice',
      'clip-path': `url(#${clipId})`,
    });
    g.appendChild(img);
    this._photoImg = img;
  }

  _buildInitialsFace(R, c) {
    const g = this._group;
    this._eyeLW = svgEl('ellipse', { rx: '2.6', ry: '3',   fill: '#fff' });
    this._eyeRW = svgEl('ellipse', { rx: '2.6', ry: '3',   fill: '#fff' });
    this._eyeLP = svgEl('circle',  { r: '1.4',             fill: '#000d2e' });
    this._eyeRP = svgEl('circle',  { r: '1.4',             fill: '#000d2e' });
    this._lidL  = svgEl('ellipse', { rx: '2.8', ry: '0',   fill: c.body });
    this._lidR  = svgEl('ellipse', { rx: '2.8', ry: '0',   fill: c.body });
    this._blushL = svgEl('ellipse', { rx: '2.5', ry: '1.5', fill: 'rgba(255,100,100,0.28)' });
    this._blushR = svgEl('ellipse', { rx: '2.5', ry: '1.5', fill: 'rgba(255,100,100,0.28)' });
    for (const e of [this._blushL, this._blushR, this._eyeLW, this._eyeRW,
                     this._eyeLP, this._eyeRP, this._lidL, this._lidR]) {
      g.appendChild(e);
    }
  }

  _spawnParticle(x, y, now) {
    if (now - this._lastParticle < 160) return;
    this._lastParticle = now;
    const p = {
      el:   svgEl('circle', { r: '2.5', fill: this._color.body, opacity: '0.5' }),
      x:    x + (Math.random() - 0.5) * 6, y,
      born: now, dur: 350,
    };
    p.el.setAttribute('cx', p.x); p.el.setAttribute('cy', p.y);
    this._particleG.appendChild(p.el);
    this._particles.push(p);
  }

  _updateParticles(now) {
    const dead = [];
    for (const p of this._particles) {
      const t = (now - p.born) / p.dur;
      if (t >= 1) { dead.push(p); continue; }
      p.el.setAttribute('cy', String(p.y + t * 5));
      p.el.setAttribute('opacity', String(0.5 * (1 - t)));
      p.el.setAttribute('r', String(2.5 * (1 - t * 0.6)));
    }
    for (const p of dead) {
      if (p.el.parentNode) p.el.parentNode.removeChild(p.el);
      this._particles.splice(this._particles.indexOf(p), 1);
    }
  }
}

// ══════════════════════════════════════════════════════════════════
// AvatarEngine  (v1 — single local avatar, backward-compatible)
// ══════════════════════════════════════════════════════════════════
export class AvatarEngine {
  constructor(opts) {
    this._svg        = opts.svgEl;
    this._W          = opts.canvasW  || 400;
    this._H          = opts.canvasH  || 600;
    this._getBlocks  = opts.getBlocks  || (() => []);
    this._getPortals = opts.getPortals || (() => []);
    this._onPortal   = opts.onPortal   || (() => {});
    this._name       = opts.name       || 'You';
    this._uid        = opts.uid        || '';
    this._photo      = opts.photo      || null;

    this._x = this._W / 2; this._y = this._H / 2;
    this._vx = 0; this._vy = 0;
    this._jx = 0; this._jy = 0;
    this._face = 1; this._isMoving = false;
    this._portalCd = 0;
    this._running = false; this._raf = null; this._lastTime = null;

    this._renderer = new AvatarRenderer(this._svg, {
      name: this._name, uid: this._uid, photo: this._photo,
      x: this._x, y: this._y,
      color: colorForUid(this._uid),
    });
  }

  start() {
    if (this._running) return;
    this._running  = true;
    this._lastTime = performance.now();
    this._raf = requestAnimationFrame(this._loop.bind(this));
  }

  stop() {
    this._running = false;
    if (this._raf) cancelAnimationFrame(this._raf);
  }

  destroy() {
    this.stop();
    this._renderer.destroy();
  }

  setJoystickVector(dx, dy) {
    this._jx = clamp(dx, -1, 1);
    this._jy = clamp(dy, -1, 1);
  }

  teleport(x, y) {
    this._x = clamp(x, AVATAR_RADIUS, this._W - AVATAR_RADIUS);
    this._y = clamp(y, AVATAR_RADIUS, this._H - AVATAR_RADIUS);
    this._vx = this._vy = 0;
  }

  setName(name) {
    this._name = name;
    if (this._renderer._labelEl) this._renderer._labelEl.textContent = name;
  }

  getPosition() { return { x: this._x, y: this._y }; }

  _loop(now) {
    if (!this._running) return;
    const dt = Math.min((now - this._lastTime) / 1000, 0.05);
    this._lastTime = now;
    this._stepPhysics(dt);
    this._renderer.stepBlink(now);
    this._renderer.stepFlash(dt);
    this._renderer.setPosition(this._x, this._y, this._face, this._isMoving);
    this._renderer.render(now);
    this._raf = requestAnimationFrame(this._loop.bind(this));
  }

  _stepPhysics(dt) {
    const mag = Math.sqrt(this._jx * this._jx + this._jy * this._jy);
    if (mag > 0.05) {
      const nx = this._jx / Math.max(mag, 1);
      const ny = this._jy / Math.max(mag, 1);
      this._vx += nx * SPEED * dt * Math.min(mag, 1);
      this._vy += ny * SPEED * dt * Math.min(mag, 1);
      if (Math.abs(this._jx) > 0.15) this._face = this._jx > 0 ? 1 : -1;
      this._isMoving = true;
    } else {
      this._isMoving = false;
    }
    this._vx *= FRICTION; this._vy *= FRICTION;
    let nx = this._x + this._vx;
    let ny = this._y + this._vy;
    nx = clamp(nx, AVATAR_RADIUS, this._W - AVATAR_RADIUS);
    ny = clamp(ny, AVATAR_RADIUS, this._H - AVATAR_RADIUS);
    for (const b of this._getBlocks()) {
      const mtv = circleVsAABB(nx, ny, AVATAR_RADIUS, b.x, b.y, b.w, b.h);
      if (mtv) {
        nx += mtv.nx * mtv.pen; ny += mtv.ny * mtv.pen;
        const dot = this._vx * mtv.nx + this._vy * mtv.ny;
        if (dot < 0) { this._vx -= dot * mtv.nx * 1.2; this._vy -= dot * mtv.ny * 1.2; }
      }
    }
    if (Date.now() > this._portalCd) {
      for (const p of this._getPortals()) {
        if (pointInRect(nx, ny, p.x, p.y, p.w, p.h, -AVATAR_RADIUS * 0.3)) {
          this._portalCd = Date.now() + PORTAL_COOLDOWN;
          this._renderer.triggerPortalFlash();
          this._onPortal(p);
          break;
        }
      }
    }
    this._x = nx; this._y = ny;
  }
}

// ══════════════════════════════════════════════════════════════════
// MultiAvatarEngine  — v2, manages local + remote avatars
// ══════════════════════════════════════════════════════════════════
export class MultiAvatarEngine {
  /**
   * @param {object} opts
   * @param {SVGSVGElement} opts.svgEl
   * @param {number}        opts.canvasW
   * @param {number}        opts.canvasH
   * @param {() => object[]} opts.getBlocks
   * @param {() => object[]} opts.getPortals
   * @param {function}       [opts.onPortal]    callback(portal)
   * @param {function}       [opts.onPositionChange] callback(x,y) — dipanggil saat posisi lokal berubah
   * @param {string}         [opts.localUid]    uid user lokal
   * @param {string}         [opts.localName]   display name user lokal
   * @param {string}         [opts.localPhoto]  photoURL user lokal
   */
  constructor(opts) {
    this._svg        = opts.svgEl;
    this._W          = opts.canvasW  || 400;
    this._H          = opts.canvasH  || 600;
    this._getBlocks  = opts.getBlocks  || (() => []);
    this._getPortals = opts.getPortals || (() => []);
    this._onPortal   = opts.onPortal   || (() => {});
    this._onPosChange = opts.onPositionChange || null;

    this._localUid   = opts.localUid   || 'local';
    this._localName  = opts.localName  || 'You';
    this._localPhoto = opts.localPhoto || null;

    // Physics state (local avatar)
    this._x = this._W / 2; this._y = this._H / 2;
    this._vx = 0; this._vy = 0;
    this._jx = 0; this._jy = 0;
    this._face = 1; this._isMoving = false;
    this._portalCd = 0;
    this._lastPosEmit = 0;

    // Remote avatars: Map<uid, { renderer, tx, ty, x, y, face, isMoving }>
    this._remotes = new Map();

    // Local renderer (rendered on top)
    this._localRenderer = new AvatarRenderer(this._svg, {
      name:  this._localName,
      uid:   this._localUid,
      photo: this._localPhoto,
      x:     this._x, y: this._y,
      color: colorForUid(this._localUid),
    });

    this._running   = false;
    this._raf       = null;
    this._lastTime  = null;
  }

  start() {
    if (this._running) return;
    this._running  = true;
    this._lastTime = performance.now();
    this._raf = requestAnimationFrame(this._loop.bind(this));
  }

  stop() {
    this._running = false;
    if (this._raf) cancelAnimationFrame(this._raf);
  }

  destroy() {
    this.stop();
    this._localRenderer.destroy();
    for (const r of this._remotes.values()) r.renderer.destroy();
    this._remotes.clear();
  }

  setJoystickVector(dx, dy) {
    this._jx = clamp(dx, -1, 1);
    this._jy = clamp(dy, -1, 1);
  }

  setLocalName(name) {
    this._localName = name;
    if (this._localRenderer._labelEl) this._localRenderer._labelEl.textContent = name;
  }

  getLocalPosition() { return { x: Math.round(this._x), y: Math.round(this._y) }; }

  /**
   * Perbarui posisi avatar remote.
   * @param {string} uid
   * @param {object} data { x, y, face, name, photoURL, isMoving }
   */
  updateRemote(uid, data) {
    if (uid === this._localUid) return;
    if (data === null) {
      // Remove
      const existing = this._remotes.get(uid);
      if (existing) { existing.renderer.destroy(); this._remotes.delete(uid); }
      return;
    }
    let remote = this._remotes.get(uid);
    if (!remote) {
      const renderer = new AvatarRenderer(this._svg, {
        name:  data.name  || uid,
        uid,
        photo: data.photoURL || null,
        color: colorForUid(uid),
        x:     data.x || this._W / 2,
        y:     data.y || this._H / 2,
      });
      // Ensure local avatar stays on top
      if (this._localRenderer._group.parentNode) {
        this._svg.insertBefore(renderer._group, this._localRenderer._group);
      }
      remote = { renderer, tx: data.x, ty: data.y, x: data.x, y: data.y, face: 1, isMoving: false };
      this._remotes.set(uid, remote);
    } else if (data.photoURL && data.photoURL !== remote.renderer._photo) {
      // photoURL berubah (atau baru tersedia) — rebuild renderer agar pakai foto terbaru
      const oldRenderer = remote.renderer;
      const newRenderer = new AvatarRenderer(this._svg, {
        name:  data.name || remote.renderer._name || uid,
        uid,
        photo: data.photoURL,
        color: colorForUid(uid),
        x:     remote.x,
        y:     remote.y,
      });
      if (this._localRenderer._group.parentNode) {
        this._svg.insertBefore(newRenderer._group, this._localRenderer._group);
      }
      oldRenderer.destroy();
      remote.renderer = newRenderer;
    }
    remote.tx = data.x;
    remote.ty = data.y;
    remote.face      = data.face      ?? remote.face;
    remote.isMoving  = data.isMoving  ?? false;
    if (data.name) remote.renderer._labelEl && (remote.renderer._labelEl.textContent = data.name);
  }

  _loop(now) {
    if (!this._running) return;
    const dt = Math.min((now - this._lastTime) / 1000, 0.05);
    this._lastTime = now;

    this._stepPhysics(dt);

    // Interpolate remote avatars
    for (const [uid, r] of this._remotes) {
      r.x += (r.tx - r.x) * REMOTE_LERP;
      r.y += (r.ty - r.y) * REMOTE_LERP;
      r.renderer.stepBlink(now);
      r.renderer.stepFlash(dt);
      r.renderer.setPosition(r.x, r.y, r.face, r.isMoving);
      r.renderer.render(now);
    }

    // Local renderer
    this._localRenderer.stepBlink(now);
    this._localRenderer.stepFlash(dt);
    this._localRenderer.setPosition(this._x, this._y, this._face, this._isMoving);
    this._localRenderer.render(now);

    this._raf = requestAnimationFrame(this._loop.bind(this));
  }

  _stepPhysics(dt) {
    const mag = Math.sqrt(this._jx * this._jx + this._jy * this._jy);
    if (mag > 0.05) {
      const nx = this._jx / Math.max(mag, 1);
      const ny = this._jy / Math.max(mag, 1);
      this._vx += nx * SPEED * dt * Math.min(mag, 1);
      this._vy += ny * SPEED * dt * Math.min(mag, 1);
      if (Math.abs(this._jx) > 0.15) this._face = this._jx > 0 ? 1 : -1;
      this._isMoving = true;
    } else {
      this._isMoving = false;
    }
    this._vx *= FRICTION; this._vy *= FRICTION;
    let nx = this._x + this._vx;
    let ny = this._y + this._vy;
    nx = clamp(nx, AVATAR_RADIUS, this._W - AVATAR_RADIUS);
    ny = clamp(ny, AVATAR_RADIUS, this._H - AVATAR_RADIUS);
    for (const b of this._getBlocks()) {
      const mtv = circleVsAABB(nx, ny, AVATAR_RADIUS, b.x, b.y, b.w, b.h);
      if (mtv) {
        nx += mtv.nx * mtv.pen; ny += mtv.ny * mtv.pen;
        const dot = this._vx * mtv.nx + this._vy * mtv.ny;
        if (dot < 0) { this._vx -= dot * mtv.nx * 1.2; this._vy -= dot * mtv.ny * 1.2; }
      }
    }
    if (Date.now() > this._portalCd) {
      for (const p of this._getPortals()) {
        if (pointInRect(nx, ny, p.x, p.y, p.w, p.h, -AVATAR_RADIUS * 0.3)) {
          this._portalCd = Date.now() + PORTAL_COOLDOWN;
          this._localRenderer.triggerPortalFlash();
          this._onPortal(p);
          break;
        }
      }
    }
    this._x = nx; this._y = ny;

    // Emit posisi ke Firebase (max ~5 fps untuk hemat kuota)
    const now = Date.now();
    if (now - this._lastPosEmit > 200 && this._onPosChange) {
      this._lastPosEmit = now;
      this._onPosChange(Math.round(this._x), Math.round(this._y), this._face, this._isMoving);
    }
  }
}
