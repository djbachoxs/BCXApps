// ── PROFILE MODAL & SIGN OUT ──
import { auth, db, doc, setDoc, fbSignOut } from './config.js';
import { state } from './state.js';
import { showToast, initials, hsl } from './utils.js';
import { openModal, closeModal } from './ui.js';
import { setPresence } from './presence.js';
import { updateProfile } from './config.js';

const CLOUDINARY_CLOUD  = 'dnhkhu8md';
const CLOUDINARY_PRESET = 'Tapwot-Catalog';

// ── STEP 1: Compress & convert to WebP via Canvas ──
function compressToWebP(file, { maxSize = 256, quality = 0.75 } = {}) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);

      // Hitung dimensi baru — crop persegi dari tengah, lalu resize ke maxSize
      const srcW = img.naturalWidth;
      const srcH = img.naturalHeight;
      const side = Math.min(srcW, srcH);
      const sx   = (srcW - side) / 2;
      const sy   = (srcH - side) / 2;

      const canvas = document.createElement('canvas');
      canvas.width  = maxSize;
      canvas.height = maxSize;
      const ctx = canvas.getContext('2d');

      // Gambar crop + resize sekaligus
      ctx.drawImage(img, sx, sy, side, side, 0, 0, maxSize, maxSize);

      canvas.toBlob(
        blob => {
          if (!blob) { reject(new Error('Kompresi gagal')); return; }
          // Bungkus sebagai File agar filename jelas
          const webpFile = new File([blob], 'avatar.webp', { type: 'image/webp' });
          resolve(webpFile);
        },
        'image/webp',
        quality
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Gagal membaca gambar'));
    };

    img.src = objectUrl;
  });
}

// ── STEP 2: Upload WebP ke Cloudinary ──
async function uploadToCloudinary(file) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_PRESET);
  formData.append('folder', 'fc_avatars');

  const res = await fetch(
    `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD}/image/upload`,
    { method: 'POST', body: formData }
  );

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Upload gagal');
  }

  const data = await res.json();
  return data.secure_url;
}

// ── Helpers UI avatar ──
function setAvatarEl(el, url, fallbackText) {
  if (!el) return;
  if (url) {
    el.innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit"
      onerror="this.parentElement.textContent='${fallbackText}'">`;
  } else {
    el.textContent = fallbackText;
  }
}

// ── openProfile ──
export function openProfile() {
  const name   = state.currentUser?.displayName || '';
  const status = state.userStatus || '';
  document.getElementById('edit-name').value   = name;
  document.getElementById('edit-status').value = status;
  document.getElementById('status-char-count').textContent = status.length;
  document.getElementById('profile-error').classList.remove('show');

  const av = document.getElementById('profile-avatar-modal');
  if (av) {
    av.style.background = `linear-gradient(135deg, ${hsl(state.currentUser.uid)}, #7c3aed)`;
    setAvatarEl(av, state.currentUser?.photoURL, initials(name));
  }

  const mn = document.getElementById('profile-modal-name');
  if (mn) mn.textContent = name;

  const me = document.getElementById('profile-modal-email');
  if (me) {
    const rawEmail = state.currentUser.email || '';
    me.textContent = rawEmail.endsWith('@flashchat.internal')
      ? '@' + rawEmail.replace('@flashchat.internal', '')
      : rawEmail;
  }

  openModal('modal-profile');
}

// ── initProfileListeners ──
export function initProfileListeners() {
  // Status char counter
  const statusInput = document.getElementById('edit-status');
  const statusCount = document.getElementById('status-char-count');
  if (statusInput && statusCount) {
    statusInput.addEventListener('input', () => {
      statusCount.textContent = statusInput.value.length;
    });
  }

  // ── Profile picture: compress → WebP → Cloudinary ──
  const picInput = document.getElementById('profile-pic-input');
  if (picInput) {
    picInput.addEventListener('change', async () => {
      const file = picInput.files[0];
      if (!file) return;

      // Validasi tipe
      if (!file.type.startsWith('image/')) {
        showToast('File harus berupa gambar.');
        picInput.value = '';
        return;
      }

      // Validasi ukuran mentah (maks 10MB sebelum kompresi)
      if (file.size > 10 * 1024 * 1024) {
        showToast('Ukuran file maksimal 10MB.');
        picInput.value = '';
        return;
      }

      const av          = document.getElementById('profile-avatar-modal');
      const origContent = av.innerHTML;

      // Tampilkan progress bertahap
      const setStatus = msg => {
        av.innerHTML = `<div style="
          display:flex;flex-direction:column;align-items:center;justify-content:center;
          gap:4px;width:100%;height:100%;font-size:14.4px;color:#fff;text-align:center;padding:6px">
          <div style="font-size:25.9px">⏳</div>
          <div>${msg}</div>
        </div>`;
      };

      try {
        // — Kompres & crop jadi WebP 256×256, quality 75% —
        setStatus('Mengompresi…');
        const webpFile = await compressToWebP(file, { maxSize: 256, quality: 0.75 });

        const kbBefore = (file.size / 1024).toFixed(1);
        const kbAfter  = (webpFile.size / 1024).toFixed(1);
        console.log(`[Avatar] ${kbBefore}KB → ${kbAfter}KB (WebP)`);

        // — Upload ke Cloudinary —
        setStatus('Mengunggah…');
        const url = await uploadToCloudinary(webpFile);

        // — Simpan ke Firebase Auth & Firestore —
        await updateProfile(state.currentUser, { photoURL: url });
        await setDoc(doc(db, 'fc_users', state.currentUser.uid), { photoURL: url }, { merge: true });

        // — Update UI —
        setAvatarEl(av, url, initials(state.currentUser.displayName || ''));
        setAvatarEl(document.getElementById('profile-avatar'), url, initials(state.currentUser.displayName || ''));

        showToast(`Foto profil dipasang! 🎉 (${kbBefore}KB → ${kbAfter}KB)`);
      } catch (e) {
        console.error('[Avatar upload]', e);
        av.innerHTML = origContent;
        showToast('Gagal upload foto: ' + (e.message || 'Coba lagi.'));
      }

      picInput.value = '';
    });
  }

  // ── Save profile ──
  document.getElementById('btn-save-profile').onclick = async () => {
    const name   = document.getElementById('edit-name').value.trim();
    const status = document.getElementById('edit-status').value.trim();
    const errEl  = document.getElementById('profile-error');
    errEl.classList.remove('show');

    if (!name || name.length < 2) {
      errEl.textContent = 'Nama minimal 2 karakter.';
      errEl.classList.add('show');
      return;
    }

    document.getElementById('btn-save-profile').disabled = true;
    try {
      await updateProfile(state.currentUser, { displayName: name });
      const statusSetAt = status ? new Date().toISOString() : null;
      await setDoc(doc(db, 'fc_users', state.currentUser.uid),
        { displayName: name, status, statusSetAt }, { merge: true });
      await setDoc(doc(db, 'fc_presence', state.currentUser.uid),
        { displayName: name }, { merge: true });

      state.userStatus = status;
      document.getElementById('profile-name').textContent   = name;
      document.getElementById('profile-avatar').textContent = initials(name);
      closeModal('modal-profile');
      showToast('Profil berhasil diperbarui! ✨');
    } catch (e) {
      errEl.textContent = 'Gagal menyimpan.';
      errEl.classList.add('show');
    }
    document.getElementById('btn-save-profile').disabled = false;
  };
}

// ── Sign out ──
export async function signOut() {
  await setPresence(false);
  const { cleanupListeners } = await import('./app.js');
  cleanupListeners();
  await fbSignOut(auth);
  closeModal('modal-profile');
}
