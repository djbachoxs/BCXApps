// ── PRESENCE & TYPING INDICATOR ──
import { db, collection, doc, setDoc, getDoc, getDocs, onSnapshot, query, where, serverTimestamp } from './config.js';
import { state } from './state.js';
import { resolvedName } from './utils.js';

export async function setPresence(online) {
  if (!state.currentUser) return;
  try {
    await setDoc(doc(db, 'fc_presence', state.currentUser.uid), {
      online,
      displayName: state.currentUser.displayName || 'Pengguna',
      uid: state.currentUser.uid,
      lastSeen: serverTimestamp(),
    }, { merge: true });
  } catch (e) {}
}

export async function setTyping(roomId) {
  if (!state.currentUser || !roomId) return;
  try {
    await setDoc(doc(db, 'fc_presence', state.currentUser.uid), {
      typingIn: roomId,
      typingAt: serverTimestamp(),
    }, { merge: true });
  } catch (e) {}
}

export async function clearTyping() {
  if (!state.currentUser) return;
  state.isTyping = false;
  try {
    await setDoc(doc(db, 'fc_presence', state.currentUser.uid), {
      typingIn: null,
      typingAt: null,
    }, { merge: true });
  } catch (e) {}
}

export function listenTyping(roomId) {
  if (state.typingUnsub) state.typingUnsub();
  document.getElementById('typing-bar').innerHTML = '';

  state.typingUnsub = onSnapshot(
    query(collection(db, 'fc_presence'), where('typingIn', '==', roomId)),
    snap => {
      const now    = Date.now();
      const typers = [];
      snap.forEach(d => {
        if (d.id === state.currentUser.uid) return;
        const data     = d.data();
        const typedAt  = data.typingAt?.toMillis?.() || 0;
        if (now - typedAt > 5000) return;
        typers.push(resolvedName(d.id, data.displayName || 'Seseorang'));
      });

      const bar = document.getElementById('typing-bar');
      if (typers.length === 0) { bar.innerHTML = ''; return; }

      let nameHtml, textHtml;
      if (typers.length === 1) {
        nameHtml = `<span class="typing-pill-name">${typers[0]}</span>`;
        textHtml = `<span style="white-space:nowrap;flex-shrink:0">sedang mengetik</span>`;
      } else if (typers.length === 2) {
        nameHtml = `<span class="typing-pill-name">${typers[0]} &amp; ${typers[1]}</span>`;
        textHtml = `<span style="white-space:nowrap;flex-shrink:0">sedang mengetik</span>`;
      } else {
        nameHtml = `<span class="typing-pill-name">${typers.length} orang</span>`;
        textHtml = `<span style="white-space:nowrap;flex-shrink:0">sedang mengetik</span>`;
      }

      bar.innerHTML = `
        <div class="typing-pill">
          <div class="typing-dots"><span></span><span></span><span></span></div>
          ${nameHtml}
          ${textHtml}
        </div>`;
    }
  );
}

export function listenPresence() {
  if (state.presenceUnsub) state.presenceUnsub();
  const q = query(collection(db, 'fc_presence'), where('online', '==', true));

  state.presenceUnsub = onSnapshot(q, snap => {
    const now      = Date.now();
    const onlineEl = document.getElementById('online-list');

    // Kumpulkan entri yang valid (lastSeen < 90 detik)
    const entries = [];
    snap.forEach(d => {
      const data = d.data();
      const ls   = data.lastSeen?.toDate?.() || new Date(0);
      if (now - ls.getTime() > 90000) return;
      entries.push({ uid: d.id, data });
    });

    if (entries.length === 0) {
      onlineEl.innerHTML = '<div style="font-size:18.7px;color:var(--text-muted);padding:4px 8px">Tidak ada yang online</div>';
      return;
    }

    // Tampilkan dulu pakai data dari fc_presence (tanpa status)
    // lalu fetch status semua user secara paralel
    _renderOnlineList(onlineEl, entries, {});

    // Fetch status semua user sekaligus (paralel, bukan sequential)
    Promise.all(
      entries.map(({ uid }) =>
        getDoc(doc(db, 'fc_users', uid))
          .then(uSnap => {
            if (!uSnap.exists()) return { uid, status: '' };
            const d = uSnap.data();
            const setAt = d.statusSetAt ? new Date(d.statusSetAt).getTime() : 0;
            if (d.status && Date.now() - setAt < 86400000) {
              return { uid, status: d.status };
            }
            // Status expired — hapus dari server diam-diam
            if (d.status) {
              setDoc(doc(db, 'fc_users', uid), { status: '', statusSetAt: null }, { merge: true }).catch(() => {});
            }
            return { uid, status: '' };
          })
          .catch(() => ({ uid, status: '' }))
      )
    ).then(results => {
      const statusMap = {};
      results.forEach(r => { statusMap[r.uid] = r.status; });
      // Re-render dengan data status lengkap
      _renderOnlineList(onlineEl, entries, statusMap);
    });
  });
}

function _renderOnlineList(onlineEl, entries, statusMap) {
  onlineEl.innerHTML = '';
  entries.forEach(({ uid, data }) => {
    const isMe   = uid === state.currentUser.uid;
    const status = statusMap[uid] || '';

    const div = document.createElement('div');
    div.className = 'online-user';
    if (isMe) {
      div.classList.add('online-user-me');
      div.onclick = () => window.openStatusModal && window.openStatusModal(status);
    }
    div.innerHTML = `
      <div class="online-dot"></div>
      <div class="online-user-info">
        <div class="online-name${isMe ? ' me' : ''}">
          ${data.displayName || 'Pengguna'}${isMe ? ' <span class="online-me-tag">(kamu)</span>' : ''}
        </div>
        ${status ? `<div class="online-status" title="${status.replace(/"/g,'&quot;')}">${status}</div>` : ''}
        ${isMe ? `<div class="online-status-hint">✏️ Ketuk untuk ubah status</div>` : ''}
      </div>`;
    onlineEl.appendChild(div);
  });
}
