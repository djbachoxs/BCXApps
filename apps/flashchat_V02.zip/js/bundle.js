// ═══════════════════════════════════════════════════════
//  FLASHCHAT — FULLY BUNDLED (no ES modules)
//  Compatible with iframe srcdoc (no import/export)
// ═══════════════════════════════════════════════════════

// ── SHARED STATE ──
const state = {
  currentUser: null, currentRoomId: null, currentRoomData: null,
  messagesUnsub: null, roomsUnsub: null, presenceUnsub: null, typingUnsub: null,
  heartbeatInterval: null, messageTimers: new Map(), cachedMembersData: [],
  typingTimeout: null, isTyping: false, userStatus: '',
};

// ── FIREBASE GLOBALS (set after init) ──
let auth, db, storage;
let _onAuthStateChanged, _signInWithEmailAndPassword, _createUserWithEmailAndPassword,
    _updateProfile, _fbSignOut, _GoogleAuthProvider, _signInWithPopup, _signInWithRedirect, _getRedirectResult,
    _collection, _doc, _addDoc, _setDoc, _getDoc, _getDocs,
    _updateDoc, _deleteDoc, _onSnapshot, _query, _where, _orderBy,
    _serverTimestamp, _Timestamp, _ref, _uploadBytes, _getDownloadURL;

// ── UTILS ──
function showToast(msg, dur = 2500) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), dur);
}
function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).map(w => w[0]).join('').toUpperCase().slice(0, 2);
}
function hsl(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 360;
  return `hsl(${h},60%,60%)`;
}
function escapeHTML(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/\n/g,'<br>');
}
function friendlyError(code) {
  const map = {
    'auth/user-not-found': 'Akun tidak ditemukan.',
    'auth/wrong-password': 'Password salah.',
    'auth/email-already-in-use': 'Email sudah terdaftar.',
    'auth/weak-password': 'Password terlalu lemah (min 6 karakter).',
    'auth/invalid-email': 'Format email tidak valid.',
    'auth/too-many-requests': 'Terlalu banyak percobaan. Coba lagi nanti.',
    'auth/invalid-credential': 'Email atau password salah.',
  };
  return map[code] || 'Terjadi kesalahan. Coba lagi.';
}
const NAME_THEMES = {
  hewan: ['Rubah','Beruang','Harimau','Singa','Gajah','Kuda','Rusa','Serigala','Elang','Lumba-lumba','Cheetah','Jaguar','Panda','Koala','Kura-kura','Kuda Nil','Badak','Jerapah','Zebra','Flamingo','Pinguin','Hiu','Paus','Gurita','Bunglon','Salamander','Ular','Gagak','Hantu Laut','Musang'],
  tokoh: ['Socrates','Cleopatra','Newton','Da Vinci','Darwin','Einstein','Tesla','Curie','Gandhi','Mandela','Aristoteles','Plato','Confucius','Hypatia','Copernicus','Galileo','Descartes','Pasteur','Turing','Hawking','Napoleon','Caesar','Attila','Genghis','Saladin','Nefertiti','Rumi','Ibn Battuta','Avicenna','Al-Khwarizmi'],
  pohon: ['Mahoni','Jati','Pinus','Cemara','Beringin','Akasia','Bambu','Kelapa','Mangga','Rambutan','Durian','Nangka','Jambu','Pepaya','Pisang','Alpukat','Karet','Sengon','Meranti','Ulin','Eboni','Gaharu','Kayu Manis','Cendana','Kapur','Kenanga','Flamboyan','Trembesi','Dadap','Waru'],
  buah:  ['Mangga','Durian','Nanas','Pepaya','Jambu','Rambutan','Salak','Sirsak','Belimbing','Manggis','Melon','Semangka','Anggur','Stroberi','Blueberry','Leci','Longan','Markisa','Kedondong','Duku','Langsat','Cempedak','Sukun','Sawo','Nangka','Matoa','Keluak','Kawista','Buni','Asam Jawa'],
  planet:['Merkurius','Venus','Mars','Jupiter','Saturnus','Uranus','Neptunus','Pluto','Io','Europa','Ganymede','Callisto','Titan','Enceladus','Triton','Charon','Eris','Makemake','Haumea','Ceres','Vesta','Pallas','Hygiea','Sedna','Quaoar','Orcus','Varuna','Ixion','Chaos','Logos'],
  majapahit:['Raden Wijaya','Jayanagara','Tribhuwana','Hayam Wuruk','Wikramawardhana','Suhita','Kertawijaya','Rajasawardhana','Purwawisesa','Bhre Pandansalas','Girindrawardhana','Patih Gajah Mada','Adityawarman','Mpu Tantular','Mpu Prapanca','Dyah Gitarja','Bhre Wirabhumi','Bhre Mataram','Arya Damar','Tanca','Ranggalawe','Sora','Nambi','Kebo Iwa','Lembu Sora','Bhre Tumapel','Bhre Lasem','Bhre Pajang','Bhre Daha','Bhre Kahuripan'],
};
function uidToIndex(uid, len) {
  let h = 0;
  for (let i = 0; i < uid.length; i++) h = (h * 31 + uid.charCodeAt(i)) >>> 0;
  return h % len;
}
function getAlias(uid, theme) {
  if (!theme || theme === 'none') return null;
  const list = NAME_THEMES[theme];
  if (!list) return null;
  return list[uidToIndex(uid, list.length)];
}
function resolvedName(uid, realName) {
  const theme = state.currentRoomData?.nameTheme;
  const alias = getAlias(uid, theme);
  return alias || realName || 'Pengguna';
}

// ── THEME ──
function toggleTheme(checkbox) {
  const theme = checkbox.checked ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', theme);
  try { localStorage.setItem('fc_theme', theme); } catch(e) {}
}
function restoreTheme() {
  try {
    const saved = localStorage.getItem('fc_theme');
    if (saved) {
      document.documentElement.setAttribute('data-theme', saved);
      if (saved === 'light') { const t = document.getElementById('theme-toggle'); if (t) t.checked = true; }
    }
  } catch(e) {}
}
function syncThemeToggle() {
  try {
    const saved = localStorage.getItem('fc_theme');
    const toggle = document.getElementById('theme-toggle');
    if (toggle && saved === 'light') toggle.checked = true;
  } catch(e) {}
}

// ── UI ──
function openModal(id) { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebar-backdrop').classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebar-backdrop').classList.remove('open');
}
function initModalBackdrops() {
  document.querySelectorAll('.modal-overlay').forEach(el => {
    el.addEventListener('click', e => { if (e.target === el) el.classList.remove('open'); });
  });
}

// ── AUTH ──
function showRegister() {
  document.getElementById('auth-login').style.display = 'none';
  document.getElementById('auth-register').style.display = '';
}
function showLogin() {
  document.getElementById('auth-register').style.display = 'none';
  document.getElementById('auth-login').style.display = '';
}
function initAuthListeners() {
  document.getElementById('btn-login').onclick = async () => {
    const email = document.getElementById('login-email').value.trim();
    const pass  = document.getElementById('login-pass').value;
    const errEl = document.getElementById('login-error');
    errEl.classList.remove('show');
    if (!email || !pass) { errEl.textContent = 'Isi semua kolom.'; errEl.classList.add('show'); return; }
    document.getElementById('btn-login').disabled = true;
    try { await _signInWithEmailAndPassword(auth, email, pass); }
    catch (e) { errEl.textContent = friendlyError(e.code); errEl.classList.add('show'); document.getElementById('btn-login').disabled = false; }
  };
  document.getElementById('btn-register').onclick = async () => {
    const email = document.getElementById('reg-email').value.trim();
    const pass  = document.getElementById('reg-pass').value;
    const name  = document.getElementById('reg-name').value.trim();
    const errEl = document.getElementById('reg-error');
    errEl.classList.remove('show');
    if (!email || !pass || !name) { errEl.textContent = 'Semua kolom wajib diisi.'; errEl.classList.add('show'); return; }
    if (name.length < 2) { errEl.textContent = 'Nama minimal 2 karakter.'; errEl.classList.add('show'); return; }
    document.getElementById('btn-register').disabled = true;
    try {
      const cred = await _createUserWithEmailAndPassword(auth, email, pass);
      await _updateProfile(cred.user, { displayName: name });
      await _setDoc(_doc(db, 'fc_users', cred.user.uid), { displayName: name, email: cred.user.email, createdAt: _serverTimestamp() });
    } catch(e) { errEl.textContent = friendlyError(e.code); errEl.classList.add('show'); document.getElementById('btn-register').disabled = false; }
  };
  const signInWithGoogle = async () => {
    const errEl = document.getElementById('login-error');
    if (errEl) errEl.classList.remove('show');
    document.querySelectorAll('.btn-google').forEach(b => b.disabled = true);
    try {
      const provider = new _GoogleAuthProvider();
      // Use redirect instead of popup — popup blocked inside iframe/PWA
      await _signInWithRedirect(auth, provider);
      // Page will reload after redirect; result handled in bootFirebase via getRedirectResult
    } catch(e) {
      const msg = friendlyError(e.code);
      const el = document.getElementById('login-error');
      if (el) { el.textContent = msg; el.classList.add('show'); }
      document.querySelectorAll('.btn-google').forEach(b => b.disabled = false);
    }
  };
  document.getElementById('btn-google-login').onclick    = signInWithGoogle;
  document.getElementById('btn-google-register').onclick = signInWithGoogle;
}
function initSetNameListener(initAppFn) {
  document.getElementById('btn-setname').onclick = async () => {
    const name  = document.getElementById('setname-input').value.trim();
    const errEl = document.getElementById('setname-error');
    errEl.classList.remove('show');
    if (!name || name.length < 2) { errEl.textContent = 'Nama minimal 2 karakter.'; errEl.classList.add('show'); return; }
    document.getElementById('btn-setname').disabled = true;
    try {
      await _updateProfile(state.currentUser, { displayName: name });
      await _setDoc(_doc(db, 'fc_users', state.currentUser.uid), { displayName: name, email: state.currentUser.email, createdAt: _serverTimestamp() }, { merge: true });
      document.getElementById('auth-overlay').classList.add('hidden');
      initAppFn();
    } catch(e) { errEl.textContent = 'Gagal menyimpan nama.'; errEl.classList.add('show'); document.getElementById('btn-setname').disabled = false; }
  };
}

// ── PRESENCE ──
async function setPresence(online) {
  if (!state.currentUser) return;
  try {
    await _setDoc(_doc(db, 'fc_presence', state.currentUser.uid), {
      online, displayName: state.currentUser.displayName || 'Pengguna',
      uid: state.currentUser.uid, lastSeen: _serverTimestamp(),
    }, { merge: true });
  } catch(e) {}
}
async function setTyping(roomId) {
  if (!state.currentUser || !roomId) return;
  try { await _setDoc(_doc(db, 'fc_presence', state.currentUser.uid), { typingIn: roomId, typingAt: _serverTimestamp() }, { merge: true }); } catch(e) {}
}
async function clearTyping() {
  if (!state.currentUser) return;
  state.isTyping = false;
  try { await _setDoc(_doc(db, 'fc_presence', state.currentUser.uid), { typingIn: null, typingAt: null }, { merge: true }); } catch(e) {}
}
function listenTyping(roomId) {
  if (state.typingUnsub) state.typingUnsub();
  document.getElementById('typing-bar').innerHTML = '';
  state.typingUnsub = _onSnapshot(
    _query(_collection(db, 'fc_presence'), _where('typingIn', '==', roomId)),
    snap => {
      const now = Date.now(); const typers = [];
      snap.forEach(d => {
        if (d.id === state.currentUser.uid) return;
        const data = d.data(); const typedAt = data.typingAt?.toMillis?.() || 0;
        if (now - typedAt > 5000) return;
        typers.push(resolvedName(d.id, data.displayName || 'Seseorang'));
      });
      const bar = document.getElementById('typing-bar');
      if (typers.length === 0) { bar.innerHTML = ''; return; }
      const nameHtml = typers.length === 1 ? `<span class="typing-pill-name">${typers[0]}</span>` :
                       typers.length === 2 ? `<span class="typing-pill-name">${typers[0]} &amp; ${typers[1]}</span>` :
                       `<span class="typing-pill-name">${typers.length} orang</span>`;
      bar.innerHTML = `<div class="typing-pill"><div class="typing-dots"><span></span><span></span><span></span></div>${nameHtml}<span style="white-space:nowrap;flex-shrink:0">sedang mengetik</span></div>`;
    }
  );
}
function listenPresence() {
  if (state.presenceUnsub) state.presenceUnsub();
  const q = _query(_collection(db, 'fc_presence'), _where('online', '==', true));
  state.presenceUnsub = _onSnapshot(q, async snap => {
    const now = Date.now(); const onlineEl = document.getElementById('online-list');
    onlineEl.innerHTML = ''; let count = 0;
    const entries = [];
    snap.forEach(d => {
      const data = d.data(); const ls = data.lastSeen?.toDate?.() || new Date(0);
      if (now - ls.getTime() > 90000) return;
      entries.push({ uid: d.id, data });
    });
    for (const { uid, data } of entries) {
      count++;
      const isMe = uid === state.currentUser.uid; let status = '';
      try {
        const uSnap = await _getDoc(_doc(db, 'fc_users', uid));
        if (uSnap.exists()) {
          const d = uSnap.data(); const setAt = d.statusSetAt ? new Date(d.statusSetAt).getTime() : 0;
          if (d.status && Date.now() - setAt < 86400000) status = d.status;
          else if (d.status) _setDoc(_doc(db, 'fc_users', uid), { status: '', statusSetAt: null }, { merge: true }).catch(() => {});
        }
      } catch(e) {}
      const div = document.createElement('div'); div.className = 'online-user';
      if (isMe) { div.classList.add('online-user-me'); div.onclick = () => window.openStatusModal && window.openStatusModal(status); }
      div.innerHTML = `<div class="online-dot"></div><div class="online-user-info"><div class="online-name${isMe?' me':''}">${data.displayName||'Pengguna'}${isMe?' <span class="online-me-tag">(kamu)</span>':''}</div>${status?`<div class="online-status" title="${status.replace(/"/g,'&quot;')}">${status}</div>`:''} ${isMe?`<div class="online-status-hint">✏️ Ketuk untuk ubah status</div>`:''}</div>`;
      onlineEl.appendChild(div);
    }
    if (count === 0) onlineEl.innerHTML = '<div style="font-size:13px;color:var(--text-muted);padding:4px 8px">Tidak ada yang online</div>';
  });
}

// ── MESSAGES ──
function listenMessages(roomId) {
  if (state.messagesUnsub) state.messagesUnsub();
  state.messageTimers.forEach(t => clearTimeout(t)); state.messageTimers.clear();
  const wrap = document.getElementById('messages-wrap'); wrap.innerHTML = '';
  const now = _Timestamp.now(); const cutoff = new _Timestamp(now.seconds - 60, now.nanoseconds);
  const q = _query(_collection(db, 'fc_rooms', roomId, 'messages'), _where('expiresAt', '>', cutoff), _orderBy('expiresAt', 'asc'));
  state.messagesUnsub = _onSnapshot(q, snap => {
    const nowMs = Date.now();
    snap.docChanges().forEach(change => {
      if (change.type === 'added') {
        const msg = { id: change.doc.id, ...change.doc.data() };
        const expiresAt = msg.expiresAt?.toMillis?.() || (nowMs + 60000);
        const msLeft = expiresAt - nowMs;
        if (msLeft <= 0) return;
        renderMessage(msg, msLeft);
        const fadeDelay = Math.max(0, msLeft - 10000);
        const t = setTimeout(() => {
          document.getElementById(`msg-${msg.id}`)?.classList.add('fading');
          setTimeout(() => { document.getElementById(`msg-${msg.id}`)?.remove(); _deleteDoc(_doc(db, 'fc_rooms', roomId, 'messages', msg.id)).catch(()=>{}); checkEmpty(); }, 10000);
        }, fadeDelay);
        state.messageTimers.set(msg.id, t);
      }
      if (change.type === 'removed') { document.getElementById(`msg-${change.doc.id}`)?.remove(); checkEmpty(); }
    });
    checkEmpty(); scrollBottom(); purgeExpiredMessages(roomId);
  });
}
async function purgeExpiredMessages(roomId) {
  try {
    const now = _Timestamp.now();
    const q = _query(_collection(db, 'fc_rooms', roomId, 'messages'), _where('expiresAt', '<=', now));
    const snap = await _getDocs(q);
    snap.forEach(d => _deleteDoc(d.ref).catch(()=>{}));
  } catch(e) {}
}
function renderMessage(msg, msLeft) {
  const wrap = document.getElementById('messages-wrap');
  const empty = document.getElementById('empty-chat'); if (empty) empty.remove();
  const isOwn = msg.uid === state.currentUser.uid;
  const row = document.createElement('div'); row.className = `msg-row${isOwn?' own':''}`; row.id = `msg-${msg.id}`;
  const avatarColor = hsl(msg.uid || 'x'); const displayName = resolvedName(msg.uid, msg.displayName);
  const theme = state.currentRoomData?.nameTheme; const isAliased = theme && theme !== 'none';
  const barDur = Math.max(0, msLeft / 1000).toFixed(1);
  const timeStr = msg.sentAt?.toDate ? msg.sentAt.toDate().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '';
  const ava = isOwn ? '' : `<div class="msg-avatar" style="background:linear-gradient(135deg,${avatarColor},#7c3aed)">${initials(displayName)}</div>`;
  const senderLine = isAliased ? `<div class="msg-sender">${displayName} <span class="msg-alias">(${msg.displayName||'Pengguna'})</span></div>` : `<div class="msg-sender">${displayName}</div>`;
  row.innerHTML = `${ava}<div class="msg-content">${!isOwn?senderLine:''}<div class="msg-bubble">${escapeHTML(msg.text)}</div><div class="msg-timer-bar" style="animation-duration:${barDur}s"></div><div class="msg-meta"><span>${timeStr}</span><span class="ttl-badge"><span class="ttl-dot"></span>${Math.ceil(msLeft/1000)}d</span></div></div>`;
  wrap.appendChild(row);
}
function checkEmpty() {
  const wrap = document.getElementById('messages-wrap'); const msgs = wrap.querySelectorAll('.msg-row'); const existing = document.getElementById('empty-chat');
  if (msgs.length === 0 && !existing) {
    const e = document.createElement('div'); e.className = 'empty-chat'; e.id = 'empty-chat';
    e.innerHTML = `<h3>Mulai Percakapan</h3><p>Belum ada pesan di sini. Semua obrolan hangus otomatis dalam 60 detik.</p>`;
    wrap.appendChild(e); if (typeof lucide !== 'undefined') lucide.createIcons();
  } else if (msgs.length > 0 && existing) { existing.remove(); }
}
function scrollBottom() { const wrap = document.getElementById('messages-wrap'); wrap.scrollTop = wrap.scrollHeight; }
async function sendMessage() {
  if (!state.currentRoomId || !state.currentUser) return;
  const input = document.getElementById('msg-input'); const text = input.value.trim(); if (!text) return;
  input.value = ''; input.style.height = ''; document.getElementById('btn-send').disabled = true;
  clearTimeout(state.typingTimeout); if (state.isTyping) { state.isTyping = false; clearTyping(); }
  const now = Date.now(); const expiresAt = new _Timestamp(Math.floor((now + 60000) / 1000), 0);
  try { await _addDoc(_collection(db, 'fc_rooms', state.currentRoomId, 'messages'), { text, uid: state.currentUser.uid, displayName: state.currentUser.displayName || 'Pengguna', sentAt: _serverTimestamp(), expiresAt }); }
  catch(e) { showToast('Gagal kirim pesan.'); }
  setTimeout(() => { document.getElementById('btn-send').disabled = false; }, 300);
}
function initMessageInput() {
  const input = document.getElementById('msg-input'); const sendBtn = document.getElementById('btn-send');
  sendBtn.onclick = sendMessage;
  input.oninput = function() {
    sendBtn.disabled = !this.value.trim(); this.style.height = ''; this.style.height = Math.min(this.scrollHeight, 140) + 'px';
    if (state.currentRoomId && this.value.trim()) {
      if (!state.isTyping) { state.isTyping = true; setTyping(state.currentRoomId); }
      clearTimeout(state.typingTimeout);
      state.typingTimeout = setTimeout(() => { state.isTyping = false; clearTyping(); }, 3000);
    } else { clearTimeout(state.typingTimeout); if (state.isTyping) { state.isTyping = false; clearTyping(); } }
  };
  input.onkeydown = function(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } };
}

// ── ROOMS ──
function listenRooms() {
  if (state.roomsUnsub) state.roomsUnsub();
  const q = _collection(db, 'fc_rooms');
  state.roomsUnsub = _onSnapshot(q, snap => {
    const roomList = document.getElementById('room-list'); roomList.innerHTML = ''; let firstPublic = null;
    snap.forEach(d => {
      const room = { id: d.id, ...d.data() };
      if (room.type === 'private') { const members = room.members || []; if (!members.includes(state.currentUser.uid)) return; }
      if (!firstPublic && room.type === 'public') firstPublic = room;
      const wrap = document.createElement('div'); wrap.className = 'room-item-wrap';
      const roomEl = document.createElement('div'); roomEl.className = `room-item${state.currentRoomId === d.id ? ' active' : ''}`; roomEl.dataset.roomId = d.id;
      roomEl.innerHTML = `<span class="room-icon">${room.type === 'private' ? '🔒' : '#'}</span><span class="room-name">${room.name}</span>`;
      roomEl.onclick = () => openRoom(room); wrap.appendChild(roomEl);
      if (room.createdBy !== 'system') {
        const settingsBtn = document.createElement('div'); settingsBtn.className = 'room-settings-btn'; settingsBtn.title = 'Pengaturan room';
        settingsBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
        settingsBtn.onclick = async (e) => { e.stopPropagation(); if (state.currentRoomId !== room.id) await openRoom(room); openMembersModal(); };
        wrap.appendChild(settingsBtn);
      }
      if (room.createdBy === state.currentUser.uid && room.createdBy !== 'system') {
        const delBtn = document.createElement('div'); delBtn.className = 'room-delete-btn'; delBtn.title = 'Hapus room';
        delBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
        delBtn.onclick = (e) => { e.stopPropagation(); openDeleteConfirm(room); };
        wrap.appendChild(delBtn);
      }
      roomList.appendChild(wrap);
    });
    if (!state.currentRoomId && firstPublic) openRoom(firstPublic);
    if (typeof lucide !== 'undefined') lucide.createIcons();
    listenPresence();
  });
}
async function openRoom(room) {
  if (state.currentRoomId && state.currentRoomId !== room.id) clearTyping();
  state.currentRoomId = room.id; state.currentRoomData = room;
  try { const snap = await _getDoc(_doc(db, 'fc_rooms', room.id)); if (snap.exists()) state.currentRoomData = { id: snap.id, ...snap.data() }; } catch(e) {}
  document.getElementById('header-room-name').textContent = (state.currentRoomData.type === 'private' ? '🔒 ' : '# ') + state.currentRoomData.name;
  document.querySelectorAll('.room-item').forEach(el => el.classList.toggle('active', el.dataset.roomId === room.id));
  listenTyping(room.id); listenMessages(room.id);
}
async function openCreateRoom() {
  document.getElementById('new-room-name').value = ''; document.getElementById('create-room-error').classList.remove('show');
  const q = _query(_collection(db, 'fc_rooms'), _where('createdBy', '==', state.currentUser.uid));
  const snap = await _getDocs(q); const count = snap.size; const isFull = count >= 4;
  const countEl = document.getElementById('quota-count'); const fillEl = document.getElementById('quota-fill');
  countEl.textContent = `${count} / 4`; countEl.classList.toggle('full', isFull);
  fillEl.style.width = `${Math.min((count/4)*100,100)}%`; fillEl.classList.toggle('full', isFull);
  const btn = document.getElementById('btn-do-create-room'); const nameInput = document.getElementById('new-room-name'); const typeSelect = document.getElementById('new-room-type');
  btn.disabled = isFull; nameInput.disabled = isFull; typeSelect.disabled = isFull;
  if (isFull) { const e = document.getElementById('create-room-error'); e.textContent = 'Kamu sudah membuat 4 room. Hapus room lama.'; e.classList.add('show'); }
  openModal('modal-create-room'); if (typeof lucide !== 'undefined') lucide.createIcons();
}
function initCreateRoomListener() {
  document.getElementById('btn-do-create-room').onclick = async () => {
    const name = document.getElementById('new-room-name').value.trim(); const type = document.getElementById('new-room-type').value;
    const errEl = document.getElementById('create-room-error'); errEl.classList.remove('show');
    if (!name) { errEl.textContent = 'Nama room wajib diisi.'; errEl.classList.add('show'); return; }
    const qCheck = _query(_collection(db, 'fc_rooms'), _where('createdBy', '==', state.currentUser.uid));
    const snapCheck = await _getDocs(qCheck);
    if (snapCheck.size >= 4) { errEl.textContent = 'Batas 4 room tercapai.'; errEl.classList.add('show'); return; }
    document.getElementById('btn-do-create-room').disabled = true;
    try {
      await _addDoc(_collection(db, 'fc_rooms'), { name, type, createdBy: state.currentUser.uid, members: [state.currentUser.uid], createdAt: _serverTimestamp() });
      closeModal('modal-create-room'); showToast(`Room "${name}" berhasil dibuat! 🎉`);
    } catch(e) { errEl.textContent = 'Gagal membuat room.'; errEl.classList.add('show'); }
    document.getElementById('btn-do-create-room').disabled = false;
  };
}
function openDeleteConfirm(room) {
  document.getElementById('modal-confirm-delete-msg').textContent = `Yakin ingin menghapus room "${room.name}"?`;
  openModal('modal-confirm-delete'); if (typeof lucide !== 'undefined') lucide.createIcons();
  const btn = document.getElementById('btn-confirm-delete-room'); const newBtn = btn.cloneNode(true); btn.parentNode.replaceChild(newBtn, btn);
  newBtn.onclick = async () => {
    newBtn.disabled = true;
    try {
      const msgSnap = await _getDocs(_collection(db, 'fc_rooms', room.id, 'messages'));
      for (const md of msgSnap.docs) await _deleteDoc(md.ref).catch(()=>{});
      await _deleteDoc(_doc(db, 'fc_rooms', room.id));
      if (state.currentRoomId === room.id) { state.currentRoomId = null; state.currentRoomData = null; }
      closeDeleteConfirm(); showToast(`Room "${room.name}" dihapus.`);
    } catch(err) { showToast('Gagal menghapus room.'); newBtn.disabled = false; }
  };
}
function closeDeleteConfirm() { closeModal('modal-confirm-delete'); }
window.closeDeleteConfirm = closeDeleteConfirm;

// ── MEMBERS ──
async function openMembersModal() {
  const room = state.currentRoomData; const isCreator = room.createdBy === state.currentUser.uid;
  const isPrivate = room.type === 'private'; const isMember = (room.members || []).includes(state.currentUser.uid);
  document.getElementById('modal-members-room-name').textContent = room.name;
  document.getElementById('invite-error').classList.remove('show');
  document.getElementById('invite-section').style.display = isCreator ? '' : 'none';
  if (isCreator) { const toggle = document.getElementById('visibility-toggle'); toggle.checked = isPrivate; updateVisibilityUI(isPrivate); updateThemeUI(room.nameTheme || 'none'); }
  document.getElementById('btn-delete-room').style.display = isCreator ? '' : 'none';
  document.getElementById('btn-leave-room').style.display = (isPrivate && !isCreator && isMember) ? '' : 'none';
  state.cachedMembersData = [];
  const ms = document.getElementById('member-search-input'); if (ms) ms.value = '';
  const si = document.getElementById('invite-search'); if (si) si.value = '';
  document.getElementById('invite-results').innerHTML = ''; document.getElementById('invite-search-clear').style.display = 'none';
  document.getElementById('members-list').innerHTML = '<div style="font-size:13px;color:var(--text-muted);padding:8px 0">Memuat…</div>';
  openModal('modal-members'); if (typeof lucide !== 'undefined') lucide.createIcons();
  await renderMembersList();
}
async function renderMembersList(filterQuery = '') {
  const room = state.currentRoomData; const membersList = document.getElementById('members-list'); const members = room.members || [];
  if (state.cachedMembersData.length === 0 || filterQuery === '__reload__') {
    membersList.innerHTML = '<div style="font-size:13px;color:var(--text-muted);padding:8px 0">Memuat…</div>';
    state.cachedMembersData = [];
    for (const uid of members) { try { const uDoc = await _getDoc(_doc(db, 'fc_users', uid)); const uData = uDoc.exists() ? uDoc.data() : { displayName: 'Pengguna', email: '' }; state.cachedMembersData.push({ uid, ...uData }); } catch(e) {} }
    filterQuery = '';
  }
  const kw = filterQuery.toLowerCase().trim(); const filtered = kw ? state.cachedMembersData.filter(u => (u.displayName||'').toLowerCase().includes(kw)||(u.email||'').toLowerCase().includes(kw)) : state.cachedMembersData;
  membersList.innerHTML = '';
  if (filtered.length === 0) { membersList.innerHTML = `<div style="font-size:13px;color:var(--text-muted);padding:8px 0">${kw ? 'Anggota tidak ditemukan.' : 'Belum ada anggota'}</div>`; return; }
  filtered.forEach(uData => {
    const alias = getAlias(uData.uid, state.currentRoomData?.nameTheme); const displayLabel = alias ? `${alias} <span style="font-size:11px;color:var(--text-muted);font-style:italic">(${uData.displayName})</span>` : uData.displayName;
    const div = document.createElement('div'); div.className = 'member-item';
    div.innerHTML = `<div class="avatar" style="background:linear-gradient(135deg,${hsl(uData.uid)},#7c3aed)">${initials(alias||uData.displayName)}</div><div><div style="font-size:14px;font-weight:500;color:var(--text-primary)">${displayLabel}</div><div style="font-size:12px;color:var(--text-muted)">${uData.email}</div></div><div class="member-role">${uData.uid === room.createdBy ? 'Pembuat' : 'Anggota'}</div>`;
    membersList.appendChild(div);
  });
}
function filterMembersList(val) { renderMembersList(val); }
function updateVisibilityUI(isPrivate) {
  document.getElementById('visibility-label').textContent = isPrivate ? 'Privat' : 'Terbuka';
  document.getElementById('visibility-desc').textContent = isPrivate ? 'Hanya anggota yang diundang dapat bergabung' : 'Semua anggota bisa melihat dan bergabung';
  const iconEl = document.getElementById('visibility-icon-el'); if (iconEl) iconEl.setAttribute('data-lucide', isPrivate ? 'lock' : 'eye');
  if (typeof lucide !== 'undefined') lucide.createIcons();
}
async function toggleRoomVisibility(checkbox) {
  if (!state.currentRoomData || !state.currentUser) return;
  const isPrivate = checkbox.checked; const newType = isPrivate ? 'private' : 'public'; checkbox.disabled = true;
  try {
    await _updateDoc(_doc(db, 'fc_rooms', state.currentRoomData.id), { type: newType }); state.currentRoomData.type = newType;
    updateVisibilityUI(isPrivate); document.getElementById('header-room-name').textContent = (newType === 'private' ? '🔒 ' : '# ') + state.currentRoomData.name;
    showToast(`Room diubah ke ${isPrivate ? 'Privat 🔒' : 'Terbuka 🌐'}`);
  } catch(e) { checkbox.checked = !isPrivate; showToast('Gagal mengubah visibilitas.'); }
  checkbox.disabled = false;
}
function updateThemeUI(theme) {
  document.querySelectorAll('.theme-dropdown-item').forEach(el => el.classList.toggle('active', el.dataset.theme === theme));
  const activeItem = document.querySelector(`.theme-dropdown-item[data-theme="${theme}"]`);
  if (activeItem) {
    const iconEl = document.getElementById('theme-select-icon'); const labelEl = document.getElementById('theme-select-label');
    if (iconEl) iconEl.innerHTML = activeItem.querySelector('.theme-dd-icon').innerHTML;
    if (labelEl) labelEl.textContent = activeItem.querySelector('.theme-dd-name').textContent;
  }
  const preview = document.getElementById('theme-alias-preview'); if (!preview) return;
  if (!theme || theme === 'none') { preview.innerHTML = 'Nama tampil seperti biasa'; }
  else { const myAlias = getAlias(state.currentUser.uid, theme); const emoji = {hewan:'🦊',tokoh:'🌍',pohon:'🌳',buah:'🍎',planet:'🪐',majapahit:'♛'}[theme]||'✨'; preview.innerHTML = `Namamu tampil sebagai ${emoji} <span>${myAlias}</span>`; }
}
async function setRoomTheme(theme) {
  if (!state.currentRoomData || !state.currentUser) return;
  if (state.currentRoomData.createdBy !== state.currentUser.uid) return;
  try {
    await _updateDoc(_doc(db, 'fc_rooms', state.currentRoomData.id), { nameTheme: theme }); state.currentRoomData.nameTheme = theme;
    updateThemeUI(theme); state.cachedMembersData = []; await renderMembersList();
    showToast(`Tema nama: ${theme === 'none' ? 'Nama asli' : theme.charAt(0).toUpperCase()+theme.slice(1)} ✨`);
  } catch(e) { showToast('Gagal mengubah tema.'); }
}
async function leaveRoom() {
  if (!state.currentRoomData || !state.currentUser) return;
  const room = state.currentRoomData; if (!confirm(`Keluar dari room "${room.name}"?`)) return;
  try {
    const newMembers = (room.members || []).filter(uid => uid !== state.currentUser.uid);
    await _updateDoc(_doc(db, 'fc_rooms', room.id), { members: newMembers }); closeModal('modal-members');
    state.currentRoomId = null; state.currentRoomData = null; showToast(`Kamu telah keluar dari room "${room.name}".`);
  } catch(e) { showToast('Gagal keluar dari room.'); }
}
async function deleteRoom() {
  if (!state.currentRoomData || !state.currentUser) return;
  const room = state.currentRoomData;
  if (room.createdBy !== state.currentUser.uid) { showToast('Hanya kreator yang bisa menghapus room.'); return; }
  if (!confirm(`Hapus room "${room.name}" secara permanen?`)) return;
  try {
    const msgSnap = await _getDocs(_collection(db, 'fc_rooms', room.id, 'messages'));
    for (const d of msgSnap.docs) await _deleteDoc(d.ref).catch(()=>{});
    await _deleteDoc(_doc(db, 'fc_rooms', room.id)); closeModal('modal-members');
    state.currentRoomId = null; state.currentRoomData = null; showToast(`Room "${room.name}" telah dihapus.`);
  } catch(e) { showToast('Gagal menghapus room.'); }
}
let inviteSearchTimer = null;
function clearInviteSearch() {
  document.getElementById('invite-search').value = ''; document.getElementById('invite-results').innerHTML = ''; document.getElementById('invite-search-clear').style.display = 'none';
}
function initInviteSearch() {
  const searchInput = document.getElementById('invite-search'); if (!searchInput || searchInput._listenerAdded) return; searchInput._listenerAdded = true;
  searchInput.addEventListener('input', () => {
    const q = searchInput.value.trim(); document.getElementById('invite-search-clear').style.display = q ? '' : 'none';
    clearTimeout(inviteSearchTimer); if (!q) { document.getElementById('invite-results').innerHTML = ''; return; }
    inviteSearchTimer = setTimeout(() => searchUsers(q), 280);
  });
}
async function searchUsers(keyword) {
  const resultsEl = document.getElementById('invite-results'); resultsEl.innerHTML = `<div class="invite-result-hint">Mencari…</div>`;
  const kw = keyword.toLowerCase();
  try {
    const snap = await _getDocs(_collection(db, 'fc_users')); const currentMembers = state.currentRoomData.members || []; const matches = [];
    snap.forEach(d => { if (d.id === state.currentUser.uid) return; const data = d.data(); const name = (data.displayName||'').toLowerCase(); const email = (data.email||'').toLowerCase(); if (name.includes(kw)||email.includes(kw)) matches.push({ uid: d.id, ...data }); });
    resultsEl.innerHTML = '';
    if (matches.length === 0) { resultsEl.innerHTML = `<div class="invite-result-hint">Tidak ada pengguna ditemukan.</div>`; return; }
    matches.forEach(user => {
      const isMember = currentMembers.includes(user.uid); const div = document.createElement('div'); div.className = 'invite-result-item';
      div.innerHTML = `<div class="avatar" style="width:32px;height:32px;font-size:12px;border-radius:8px;background:linear-gradient(135deg,${hsl(user.uid)},#7c3aed)">${initials(user.displayName)}</div><div class="invite-result-info"><div class="invite-result-name">${user.displayName||'Pengguna'}</div><div class="invite-result-email">${user.email||''}</div></div><button class="btn-add-user${isMember?' added':''}" data-uid="${user.uid}" ${isMember?'disabled':''}>${isMember?'✓ Anggota':'+ Tambah'}</button>`;
      div.querySelector('.btn-add-user').onclick = async (e) => {
        if (isMember) return; const btn = e.currentTarget; btn.disabled = true; btn.textContent = '…';
        try {
          const members = state.currentRoomData.members || []; await _updateDoc(_doc(db, 'fc_rooms', state.currentRoomId), { members: [...members, user.uid] });
          btn.textContent = '✓ Anggota'; btn.classList.add('added'); showToast(`${user.displayName} ditambahkan! 🎉`); state.cachedMembersData = []; await renderMembersList();
        } catch(err) { btn.disabled = false; btn.textContent = '+ Tambah'; showToast('Gagal menambahkan anggota.'); }
      };
      resultsEl.appendChild(div);
    });
  } catch(e) { resultsEl.innerHTML = `<div class="invite-result-hint">Gagal memuat pengguna.</div>`; }
}

// ── PROFILE ──
function openProfile() {
  const name = state.currentUser?.displayName || ''; const status = state.userStatus || '';
  document.getElementById('edit-name').value = name; document.getElementById('edit-status').value = status;
  document.getElementById('status-char-count').textContent = status.length; document.getElementById('profile-error').classList.remove('show');
  const av = document.getElementById('profile-avatar-modal');
  if (av) {
    const photoURL = state.currentUser?.photoURL;
    if (photoURL) { av.innerHTML = `<img src="${photoURL}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.parentElement.textContent='${initials(name)}'">`;
    } else { av.textContent = initials(name); }
    av.style.background = `linear-gradient(135deg, ${hsl(state.currentUser.uid)}, #7c3aed)`;
  }
  const mn = document.getElementById('profile-modal-name'); if (mn) mn.textContent = name;
  const me = document.getElementById('profile-modal-email'); if (me) me.textContent = state.currentUser.email;
  openModal('modal-profile');
}
function initProfileListeners() {
  const statusInput = document.getElementById('edit-status'); const statusCount = document.getElementById('status-char-count');
  if (statusInput && statusCount) statusInput.addEventListener('input', () => { statusCount.textContent = statusInput.value.length; });
  const picInput = document.getElementById('profile-pic-input');
  if (picInput) {
    picInput.addEventListener('change', async () => {
      const file = picInput.files[0]; if (!file) return;
      if (file.size > 3*1024*1024) { showToast('Ukuran foto maksimal 3MB.'); return; }
      const av = document.getElementById('profile-avatar-modal'); const origContent = av.innerHTML;
      av.innerHTML = '<div style="font-size:10px;color:#fff;text-align:center;line-height:1.2">Uploading…</div>';
      try {
        const storageRef = _ref(storage, `fc_avatars/${state.currentUser.uid}`);
        const snap = await _uploadBytes(storageRef, file, { contentType: file.type }); const url = await _getDownloadURL(snap.ref);
        await _updateProfile(state.currentUser, { photoURL: url }); await _setDoc(_doc(db, 'fc_users', state.currentUser.uid), { photoURL: url }, { merge: true });
        av.innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">`;
        const sideAvatar = document.getElementById('profile-avatar'); if (sideAvatar) sideAvatar.innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">`;
        showToast('Foto profil berhasil dipasang! 🎉');
      } catch(e) { av.innerHTML = origContent; showToast('Gagal upload foto. Coba lagi.'); }
      picInput.value = '';
    });
  }
  document.getElementById('btn-save-profile').onclick = async () => {
    const name = document.getElementById('edit-name').value.trim(); const status = document.getElementById('edit-status').value.trim();
    const errEl = document.getElementById('profile-error'); errEl.classList.remove('show');
    if (!name || name.length < 2) { errEl.textContent = 'Nama minimal 2 karakter.'; errEl.classList.add('show'); return; }
    document.getElementById('btn-save-profile').disabled = true;
    try {
      await _updateProfile(state.currentUser, { displayName: name }); const statusSetAt = status ? new Date().toISOString() : null;
      await _setDoc(_doc(db, 'fc_users', state.currentUser.uid), { displayName: name, status, statusSetAt }, { merge: true });
      await _setDoc(_doc(db, 'fc_presence', state.currentUser.uid), { displayName: name }, { merge: true });
      state.userStatus = status; document.getElementById('profile-name').textContent = name;
      document.getElementById('profile-avatar').textContent = initials(name); closeModal('modal-profile'); showToast('Profil berhasil diperbarui! ✨');
    } catch(e) { errEl.textContent = 'Gagal menyimpan.'; errEl.classList.add('show'); }
    document.getElementById('btn-save-profile').disabled = false;
  };
}
async function signOut() {
  await setPresence(false); cleanupListeners(); await _fbSignOut(auth); closeModal('modal-profile');
}

// ── APP CORE ──
function cleanupListeners() {
  if (state.messagesUnsub) state.messagesUnsub(); if (state.roomsUnsub) state.roomsUnsub();
  if (state.presenceUnsub) state.presenceUnsub(); if (state.typingUnsub) state.typingUnsub();
  if (state.heartbeatInterval) clearInterval(state.heartbeatInterval);
  clearTimeout(state.typingTimeout); if (state.isTyping) clearTyping();
  state.messageTimers.forEach(t => clearTimeout(t)); state.messageTimers.clear();
  state.currentRoomId = null; state.currentRoomData = null;
}
async function initApp(nameOverride) {
  const name = nameOverride || state.currentUser.displayName || 'Pengguna';
  document.getElementById('profile-name').textContent  = name;
  document.getElementById('profile-email').textContent = state.currentUser.email;
  const av = document.getElementById('profile-avatar');
  av.style.background = `linear-gradient(135deg, ${hsl(state.currentUser.uid)}, #7c3aed)`;
  if (state.currentUser.photoURL) {
    av.innerHTML = `<img src="${state.currentUser.photoURL}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.parentElement.textContent='${initials(name)}'">`;
  } else { av.textContent = initials(name); }
  document.getElementById('edit-name').value = name;
  syncThemeToggle(); await setPresence(true);
  state.heartbeatInterval = setInterval(() => setPresence(true), 30000);
  window.addEventListener('visibilitychange', () => { document.hidden ? setPresence(false) : setPresence(true); });
  window.addEventListener('beforeunload', () => setPresence(false));
  listenRooms(); initInviteSearch();
  const searchBar = document.getElementById('header-member-search'); searchBar.style.display = 'flex';
  if (window.innerWidth <= 600) { const btn = document.getElementById('btn-menu-sidebar'); btn.style.display = 'flex'; if (typeof lucide!=='undefined') lucide.createIcons(); }
  document.getElementById('btn-menu-sidebar').onclick = toggleSidebar;
}
async function ensureDefaultRooms() {
  const rooms = ['umum','bebas'];
  for (const name of rooms) {
    const q = _query(_collection(db, 'fc_rooms'), _where('name', '==', name), _where('type', '==', 'public'));
    const snap = await _getDocs(q);
    if (snap.empty) await _addDoc(_collection(db, 'fc_rooms'), { name, type: 'public', createdBy: 'system', members: [], createdAt: _serverTimestamp() });
  }
}

// ── WINDOW GLOBALS (for onclick attributes in HTML) ──
window.showRegister = showRegister; window.showLogin = showLogin;
window.openModal = openModal; window.closeModal = closeModal;
window.toggleSidebar = toggleSidebar; window.closeSidebar = closeSidebar;
window.toggleTheme = toggleTheme; window.openCreateRoom = openCreateRoom;
window.openProfile = openProfile; window.signOut = signOut;
window.filterMembersList = filterMembersList; window.toggleRoomVisibility = toggleRoomVisibility;
window.setRoomTheme = setRoomTheme; window.leaveRoom = leaveRoom; window.deleteRoom = deleteRoom;
window.clearInviteSearch = clearInviteSearch;
let _memberSearchTimer = null;
window.toggleMemberSearch = function() {
  const bar = document.getElementById('header-member-search'); const results = document.getElementById('header-search-results'); const input = document.getElementById('header-search-input');
  const isOpen = bar.classList.contains('open'); bar.style.display = 'flex';
  if (!isOpen) { bar.classList.add('open'); setTimeout(() => input.focus(), 150); }
  else { bar.classList.remove('open'); input.value = ''; results.style.display = 'none'; results.innerHTML = ''; document.getElementById('header-search-clear').style.display = 'none'; }
};
window.clearHeaderSearch = function() {
  const input = document.getElementById('header-search-input'); const results = document.getElementById('header-search-results');
  input.value = ''; results.style.display = 'none'; results.innerHTML = ''; document.getElementById('header-search-clear').style.display = 'none'; input.focus();
};
window.headerMemberSearch = async function(val) {
  const results = document.getElementById('header-search-results'); const clearBtn = document.getElementById('header-search-clear');
  clearBtn.style.display = val ? 'flex' : 'none'; clearTimeout(_memberSearchTimer);
  if (!val.trim()) { results.style.display = 'none'; results.innerHTML = ''; return; }
  results.style.display = 'block'; results.innerHTML = `<div class="header-search-hint">Mencari…</div>`;
  _memberSearchTimer = setTimeout(async () => {
    try {
      const snap = await _getDocs(_collection(db, 'fc_users')); const kw = val.toLowerCase(); const hits = [];
      snap.forEach(d => { const data = d.data(); const name = (data.displayName||'').toLowerCase(); if (name.includes(kw)) hits.push({ uid: d.id, ...data }); });
      results.innerHTML = '';
      if (!hits.length) { results.innerHTML = `<div class="header-search-hint">Tidak ditemukan.</div>`; return; }
      hits.forEach(u => {
        const now = Date.now(); const setAt = u.statusSetAt ? new Date(u.statusSetAt).getTime() : 0; const status = (u.status && now-setAt<86400000) ? u.status : '';
        const div = document.createElement('div'); div.className = 'header-search-item';
        div.innerHTML = `<div class="avatar" style="width:32px;height:32px;font-size:12px;border-radius:9px;flex-shrink:0;background:linear-gradient(135deg,${hsl(u.uid)},#7c3aed)">${initials(u.displayName)}</div><div class="header-search-item-info"><div class="header-search-item-name">${u.displayName||'Pengguna'}</div>${status?`<div class="header-search-item-status">${status}</div>`:''}</div>`;
        results.appendChild(div);
      });
    } catch(e) { results.innerHTML = `<div class="header-search-hint">Gagal memuat.</div>`; }
  }, 280);
};
document.addEventListener('click', (e) => {
  if (!e.target.closest('#header-member-search') && !e.target.closest('#header-search-results') && !e.target.closest('#btn-members')) {
    const bar = document.getElementById('header-member-search'); const results = document.getElementById('header-search-results'); const input = document.getElementById('header-search-input');
    if (bar && bar.classList.contains('open')) { bar.classList.remove('open'); if (input) input.value=''; if (results) { results.style.display='none'; results.innerHTML=''; } const clr = document.getElementById('header-search-clear'); if (clr) clr.style.display='none'; }
  }
});
window.toggleThemeDropdown = function() {
  const dd = document.getElementById('theme-dropdown'); const btn = document.getElementById('theme-select-btn'); const wrap = document.getElementById('theme-select-wrap'); const isOpen = dd.classList.contains('open');
  if (!isOpen) { const rect = btn.getBoundingClientRect(); dd.style.top=(rect.bottom+6)+'px'; dd.style.left=rect.left+'px'; dd.style.width=rect.width+'px'; }
  dd.classList.toggle('open',!isOpen); wrap.classList.toggle('open',!isOpen);
};
window.selectThemeOption = function(theme) {
  setRoomTheme(theme); const dd = document.getElementById('theme-dropdown'); const wrap = document.getElementById('theme-select-wrap'); dd.classList.remove('open'); wrap.classList.remove('open');
  const item = document.querySelector(`.theme-dropdown-item[data-theme="${theme}"]`);
  if (item) { const iconEl = document.getElementById('theme-select-icon'); const labelEl = document.getElementById('theme-select-label'); iconEl.innerHTML = item.querySelector('.theme-dd-icon').innerHTML; labelEl.textContent = item.querySelector('.theme-dd-name').textContent; }
};
document.addEventListener('click', (e) => {
  if (!e.target.closest('#theme-select-wrap')) { const dd = document.getElementById('theme-dropdown'); const wrap = document.getElementById('theme-select-wrap'); if (dd) dd.classList.remove('open'); if (wrap) wrap.classList.remove('open'); }
});
window.openStatusModal = function(currentStatus='') {
  const ta = document.getElementById('status-textarea'); const cnt = document.getElementById('status-char');
  ta.value = currentStatus||''; cnt.textContent = ta.value.length; openModal('modal-status'); setTimeout(()=>ta.focus(),150);
};
document.addEventListener('DOMContentLoaded', () => {
  const ta = document.getElementById('status-textarea'); if (ta) ta.addEventListener('input', () => { document.getElementById('status-char').textContent = ta.value.length; });
});
window.applyStatusPreset = function(text) { const ta = document.getElementById('status-textarea'); ta.value = text; document.getElementById('status-char').textContent = text.length; ta.focus(); };
window.saveStatus = async function() {
  const ta = document.getElementById('status-textarea'); const status = ta.value.trim(); if (!state.currentUser) return;
  try { await _setDoc(_doc(db, 'fc_users', state.currentUser.uid), { status, statusSetAt: status ? new Date().toISOString() : null }, { merge: true }); state.userStatus = status; closeModal('modal-status'); showToast(status ? `Status diperbarui ✨` : 'Status dihapus'); }
  catch(e) { showToast('Gagal menyimpan status.'); }
};
window.clearStatus = async function() {
  if (!state.currentUser) return;
  try { await _setDoc(_doc(db, 'fc_users', state.currentUser.uid), { status: '', statusSetAt: null }, { merge: true }); state.userStatus = ''; document.getElementById('status-textarea').value = ''; document.getElementById('status-char').textContent = '0'; closeModal('modal-status'); showToast('Status dihapus'); }
  catch(e) { showToast('Gagal menghapus status.'); }
};

// ── FIREBASE INIT & BOOT ──
async function bootFirebase() {
  const V = '10.12.0', B = `https://www.gstatic.com/firebasejs/${V}`;
  const [appMod, authMod, fsMod, storageMod] = await Promise.all([
    import(`${B}/firebase-app.js`),
    import(`${B}/firebase-auth.js`),
    import(`${B}/firebase-firestore.js`),
    import(`${B}/firebase-storage.js`),
  ]);
  const firebaseConfig = {
    apiKey: "AIzaSyDpRvM-kzGDSl0c4Qj1srnVf6CqeFMfATA",
    authDomain: "tapchat-builder.firebaseapp.com",
    projectId: "tapchat-builder",
    storageBucket: "tapchat-builder.firebasestorage.app",
    messagingSenderId: "753773448817",
    appId: "1:753773448817:web:dad73083e70c39766e95d0",
    measurementId: "G-G3MCCL9STF",
  };
  const fbApp = appMod.initializeApp(firebaseConfig, 'flashchat');
  auth    = authMod.getAuth(fbApp);
  db      = fsMod.getFirestore(fbApp);
  storage = storageMod.getStorage(fbApp);
  _onAuthStateChanged          = authMod.onAuthStateChanged;
  _signInWithEmailAndPassword  = authMod.signInWithEmailAndPassword;
  _createUserWithEmailAndPassword = authMod.createUserWithEmailAndPassword;
  _updateProfile               = authMod.updateProfile;
  _fbSignOut                   = authMod.signOut;
  _GoogleAuthProvider          = authMod.GoogleAuthProvider;
  _signInWithPopup             = authMod.signInWithPopup;
  _signInWithRedirect          = authMod.signInWithRedirect;
  _getRedirectResult           = authMod.getRedirectResult;
  _collection  = fsMod.collection; _doc         = fsMod.doc;
  _addDoc      = fsMod.addDoc;     _setDoc      = fsMod.setDoc;
  _getDoc      = fsMod.getDoc;     _getDocs     = fsMod.getDocs;
  _updateDoc   = fsMod.updateDoc;  _deleteDoc   = fsMod.deleteDoc;
  _onSnapshot  = fsMod.onSnapshot; _query       = fsMod.query;
  _where       = fsMod.where;      _orderBy     = fsMod.orderBy;
  _serverTimestamp = fsMod.serverTimestamp; _Timestamp = fsMod.Timestamp;
  _ref           = storageMod.ref;
  _uploadBytes   = storageMod.uploadBytes;
  _getDownloadURL = storageMod.getDownloadURL;

  // Handle Google redirect result (after signInWithRedirect returns)
  try {
    const redirectResult = await _getRedirectResult(auth);
    if (redirectResult && redirectResult.user) {
      const user    = redirectResult.user;
      const userRef = _doc(db, 'fc_users', user.uid);
      const snap    = await _getDoc(userRef);
      if (!snap.exists()) {
        await _setDoc(userRef, {
          displayName: user.displayName || 'Pengguna',
          email: user.email,
          createdAt: _serverTimestamp(),
        });
      }
    }
  } catch(e) { console.warn('Redirect result error:', e.code); }

  // Auth state observer
  _onAuthStateChanged(auth, async (user) => {
    document.getElementById('loading-screen').classList.add('hidden');
    if (!user) {
      document.getElementById('auth-overlay').classList.remove('hidden');
      document.getElementById('app').classList.remove('visible');
      document.getElementById('auth-login').style.display = '';
      document.getElementById('auth-register').style.display = 'none';
      document.getElementById('auth-setname').style.display = 'none';
      cleanupListeners(); return;
    }
    state.currentUser = user;
    const userDoc = await _getDoc(_doc(db, 'fc_users', user.uid));
    const storedName = userDoc.exists() ? userDoc.data().displayName : null;
    const displayName = user.displayName || storedName;
    if (userDoc.exists()) {
      const d = userDoc.data(); const setAt = d.statusSetAt ? new Date(d.statusSetAt).getTime() : 0;
      if (d.status && Date.now()-setAt<86400000) { state.userStatus = d.status; }
      else if (d.status) { state.userStatus=''; _setDoc(_doc(db,'fc_users',user.uid),{status:'',statusSetAt:null},{merge:true}).catch(()=>{}); }
    }
    if (!displayName) {
      document.getElementById('auth-overlay').classList.remove('hidden');
      document.getElementById('auth-login').style.display    = 'none';
      document.getElementById('auth-register').style.display = 'none';
      document.getElementById('auth-setname').style.display  = ''; return;
    }
    if (!userDoc.exists()) await _setDoc(_doc(db, 'fc_users', user.uid), { displayName, email: user.email, createdAt: _serverTimestamp() });
    document.getElementById('auth-overlay').classList.add('hidden');
    document.getElementById('app').classList.add('visible');
    initApp(displayName); if (typeof lucide!=='undefined') lucide.createIcons();
  });

  ensureDefaultRooms().catch(()=>{});
}

// ── MAIN BOOT ──
document.addEventListener('DOMContentLoaded', () => {
  restoreTheme(); initModalBackdrops(); initAuthListeners();
  initSetNameListener(initApp); initCreateRoomListener(); initMessageInput(); initProfileListeners();
  if (typeof lucide !== 'undefined') lucide.createIcons();
  bootFirebase().catch(e => console.error('Firebase boot error:', e));
});
