// ── UTILITY FUNCTIONS ──
import { state } from './state.js';

// ── Toast notification ──
export function showToast(msg, dur = 2500) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), dur);
}

// ── Avatar helpers ──
export function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

export function hsl(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) % 360;
  return `hsl(${h},60%,60%)`;
}

// ── Time formatting ──
export function timeAgo(ts) {
  if (!ts) return '';
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return new Date(d).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}

// ── HTML escape ──
export function escapeHTML(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\n/g, '<br>');
}

// ── Auth error messages ──
export function friendlyError(code) {
  const map = {
    'auth/user-not-found':      'Akun tidak ditemukan.',
    'auth/wrong-password':      'Password salah.',
    'auth/email-already-in-use':'Email sudah terdaftar.',
    'auth/weak-password':       'Password terlalu lemah (min 6 karakter).',
    'auth/invalid-email':       'Format email tidak valid.',
    'auth/too-many-requests':   'Terlalu banyak percobaan. Coba lagi nanti.',
    'auth/invalid-credential':  'Email atau password salah.',
  };
  return map[code] || 'Terjadi kesalahan. Coba lagi.';
}

// ── NAME THEMES ──
export const NAME_THEMES = {
  hewan: ['Rubah','Beruang','Harimau','Singa','Gajah','Kuda','Rusa','Serigala','Elang','Lumba-lumba',
          'Cheetah','Jaguar','Panda','Koala','Kura-kura','Kuda Nil','Badak','Jerapah','Zebra','Flamingo',
          'Pinguin','Hiu','Paus','Gurita','Bunglon','Salamander','Ular','Gagak','Hantu Laut','Musang'],
  tokoh: ['Socrates','Cleopatra','Newton','Da Vinci','Darwin','Einstein','Tesla','Curie','Gandhi','Mandela',
          'Aristoteles','Plato','Confucius','Hypatia','Copernicus','Galileo','Descartes','Pasteur','Turing','Hawking',
          'Napoleon','Caesar','Attila','Genghis','Saladin','Nefertiti','Rumi','Ibn Battuta','Avicenna','Al-Khwarizmi'],
  pohon: ['Mahoni','Jati','Pinus','Cemara','Beringin','Akasia','Bambu','Kelapa','Mangga','Rambutan',
          'Durian','Nangka','Jambu','Pepaya','Pisang','Alpukat','Karet','Sengon','Meranti','Ulin',
          'Eboni','Gaharu','Kayu Manis','Cendana','Kapur','Kenanga','Flamboyan','Trembesi','Dadap','Waru'],
  buah:  ['Mangga','Durian','Nanas','Pepaya','Jambu','Rambutan','Salak','Sirsak','Belimbing','Manggis',
          'Melon','Semangka','Anggur','Stroberi','Blueberry','Leci','Longan','Markisa','Kedondong','Duku',
          'Langsat','Cempedak','Sukun','Sawo','Nangka','Matoa','Keluak','Kawista','Buni','Asam Jawa'],
  planet:['Merkurius','Venus','Mars','Jupiter','Saturnus','Uranus','Neptunus','Pluto','Io','Europa',
          'Ganymede','Callisto','Titan','Enceladus','Triton','Charon','Eris','Makemake','Haumea','Ceres',
          'Vesta','Pallas','Hygiea','Sedna','Quaoar','Orcus','Varuna','Ixion','Chaos','Logos'],
  majapahit:['Raden Wijaya','Jayanagara','Tribhuwana','Hayam Wuruk','Wikramawardhana','Suhita','Kertawijaya',
             'Rajasawardhana','Purwawisesa','Bhre Pandansalas','Girindrawardhana','Patih Gajah Mada',
             'Adityawarman','Mpu Tantular','Mpu Prapanca','Dyah Gitarja','Bhre Wirabhumi','Bhre Mataram',
             'Arya Damar','Tanca','Ranggalawe','Sora','Nambi','Kebo Iwa','Lembu Sora',
             'Bhre Tumapel','Bhre Lasem','Bhre Pajang','Bhre Daha','Bhre Kahuripan'],
};

export function uidToIndex(uid, len) {
  let h = 0;
  for (let i = 0; i < uid.length; i++) h = (h * 31 + uid.charCodeAt(i)) >>> 0;
  return h % len;
}

export function getAlias(uid, theme) {
  if (!theme || theme === 'none') return null;
  const list = NAME_THEMES[theme];
  if (!list) return null;
  return list[uidToIndex(uid, list.length)];
}

// Returns alias if room theme is active, otherwise real name
export function resolvedName(uid, realName) {
  const theme = state.currentRoomData?.nameTheme;
  const alias = getAlias(uid, theme);
  return alias || realName || 'Pengguna';
}
