// ── AUTH FLOW ──
import {
  auth, db,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  GoogleAuthProvider,
  signInWithPopup,
  doc, setDoc, getDoc, serverTimestamp,
} from './config.js';
import { state } from './state.js';
import { friendlyError } from './utils.js';

export function showRegister() {
  document.getElementById('auth-login').style.display = 'none';
  document.getElementById('auth-register').style.display = '';
}

export function showLogin() {
  document.getElementById('auth-register').style.display = 'none';
  document.getElementById('auth-login').style.display = '';
}

export function initAuthListeners() {
  // Email login
  document.getElementById('btn-login').onclick = async () => {
    const email  = document.getElementById('login-email').value.trim();
    const pass   = document.getElementById('login-pass').value;
    const errEl  = document.getElementById('login-error');
    errEl.classList.remove('show');
    if (!email || !pass) {
      errEl.textContent = 'Isi semua kolom.';
      errEl.classList.add('show');
      return;
    }
    document.getElementById('btn-login').disabled = true;
    try {
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (e) {
      errEl.textContent = friendlyError(e.code);
      errEl.classList.add('show');
      document.getElementById('btn-login').disabled = false;
    }
  };

  // Email register
  document.getElementById('btn-register').onclick = async () => {
    const email  = document.getElementById('reg-email').value.trim();
    const pass   = document.getElementById('reg-pass').value;
    const name   = document.getElementById('reg-name').value.trim();
    const errEl  = document.getElementById('reg-error');
    errEl.classList.remove('show');
    if (!email || !pass || !name) {
      errEl.textContent = 'Semua kolom wajib diisi.';
      errEl.classList.add('show');
      return;
    }
    if (name.length < 2) {
      errEl.textContent = 'Nama minimal 2 karakter.';
      errEl.classList.add('show');
      return;
    }
    document.getElementById('btn-register').disabled = true;
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      await updateProfile(cred.user, { displayName: name });
      await setDoc(doc(db, 'fc_users', cred.user.uid), {
        displayName: name, email: cred.user.email, createdAt: serverTimestamp(),
      });
    } catch (e) {
      errEl.textContent = friendlyError(e.code);
      errEl.classList.add('show');
      document.getElementById('btn-register').disabled = false;
    }
  };

  // Google sign-in
  const signInWithGoogle = async () => {
    const errEl = document.getElementById('login-error');
    if (errEl) errEl.classList.remove('show');
    document.querySelectorAll('.btn-google').forEach(b => (b.disabled = true));
    try {
      const provider = new GoogleAuthProvider();
      const result   = await signInWithPopup(auth, provider);
      const user     = result.user;
      const userRef  = doc(db, 'fc_users', user.uid);
      const userSnap = await getDoc(userRef);
      if (!userSnap.exists()) {
        await setDoc(userRef, {
          displayName: user.displayName || 'Pengguna',
          email: user.email,
          createdAt: serverTimestamp(),
        });
      }
    } catch (e) {
      const msg =
        e.code === 'auth/popup-closed-by-user' ? 'Login dibatalkan.' :
        e.code === 'auth/popup-blocked'         ? 'Popup diblokir browser. Izinkan popup untuk situs ini.' :
        friendlyError(e.code);
      const el = document.getElementById('login-error');
      if (el) { el.textContent = msg; el.classList.add('show'); }
    }
    document.querySelectorAll('.btn-google').forEach(b => (b.disabled = false));
  };

  document.getElementById('btn-google-login').onclick    = signInWithGoogle;
  document.getElementById('btn-google-register').onclick = signInWithGoogle;
}

// Set display name step (after Google sign-in with no displayName)
export function initSetNameListener(initApp) {
  document.getElementById('btn-setname').onclick = async () => {
    const name  = document.getElementById('setname-input').value.trim();
    const errEl = document.getElementById('setname-error');
    errEl.classList.remove('show');
    if (!name || name.length < 2) {
      errEl.textContent = 'Nama minimal 2 karakter.';
      errEl.classList.add('show');
      return;
    }
    document.getElementById('btn-setname').disabled = true;
    try {
      await updateProfile(state.currentUser, { displayName: name });
      await setDoc(doc(db, 'fc_users', state.currentUser.uid), {
        displayName: name, email: state.currentUser.email, createdAt: serverTimestamp(),
      }, { merge: true });
      document.getElementById('auth-overlay').classList.add('hidden');
      initApp();
    } catch (e) {
      errEl.textContent = 'Gagal menyimpan nama.';
      errEl.classList.add('show');
      document.getElementById('btn-setname').disabled = false;
    }
  };
}
