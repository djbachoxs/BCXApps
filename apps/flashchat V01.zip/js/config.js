// ── FIREBASE CONFIG & INIT ──
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import { getStorage } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js';

import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut as fbSignOut,
  GoogleAuthProvider,
  signInWithPopup,
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';

import {
  getFirestore,
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp,
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: "AIzaSyB9u5acOm9T67dYT8bfalPWGLHX6VtTY24",
  authDomain: "tapwot-web-builder-dan-admin.firebaseapp.com",
  projectId: "tapwot-web-builder-dan-admin",
  storageBucket: "tapwot-web-builder-dan-admin.firebasestorage.app",
  messagingSenderId: "793604441978",
  appId: "1:793604441978:web:3096cf7dda92f9a0e6f8c3",
  measurementId: "G-PZQ8BZ836X",
};

const app = initializeApp(firebaseConfig, 'flashchat');
export const auth = getAuth(app);
export const db      = getFirestore(app);
export const storage = getStorage(app);

// Re-export Firebase functions so other modules don't need CDN URLs
export {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  fbSignOut,
  GoogleAuthProvider,
  signInWithPopup,
  collection, doc, addDoc, setDoc, getDoc, getDocs,
  updateDoc, deleteDoc, onSnapshot, query, where, orderBy,
  serverTimestamp, Timestamp,
};
