// ── PROFILE MODAL & SIGN OUT ──
import { auth, db, doc, setDoc, fbSignOut, storage } from './config.js';
import { state } from './state.js';
import { showToast, initials, hsl } from './utils.js';
import { openModal, closeModal } from './ui.js';
import { setPresence } from './presence.js';
import { updateProfile } from './config.js';
import { ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js';

export function openProfile() {
  const name   = state.currentUser?.displayName || '';
  const status = state.userStatus || '';  // already expiry-checked on login
  document.getElementById('edit-name').value = name;
  document.getElementById('edit-status').value = status;
  document.getElementById('status-char-count').textContent = status.length;
  document.getElementById('profile-error').classList.remove('show');

  const av = document.getElementById('profile-avatar-modal');
  if (av) {
    const photoURL = state.currentUser?.photoURL;
    if (photoURL) {
      av.innerHTML = `<img src="${photoURL}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.parentElement.textContent='${initials(name)}'">`;
      av.style.background = `linear-gradient(135deg, ${hsl(state.currentUser.uid)}, #7c3aed)`;
    } else {
      av.textContent = initials(name);
      av.style.background = `linear-gradient(135deg, ${hsl(state.currentUser.uid)}, #7c3aed)`;
    }
  }
  const mn = document.getElementById('profile-modal-name');
  if (mn) mn.textContent = name;
  const me = document.getElementById('profile-modal-email');
  if (me) me.textContent = state.currentUser.email;

  openModal('modal-profile');
}

export function initProfileListeners() {
  // Status char counter
  const statusInput = document.getElementById('edit-status');
  const statusCount = document.getElementById('status-char-count');
  if (statusInput && statusCount) {
    statusInput.addEventListener('input', () => {
      statusCount.textContent = statusInput.value.length;
    });
  }

  // Profile picture upload
  const picInput = document.getElementById('profile-pic-input');
  if (picInput) {
    picInput.addEventListener('change', async () => {
      const file = picInput.files[0];
      if (!file) return;
      if (file.size > 3 * 1024 * 1024) {
        showToast('Ukuran foto maksimal 3MB.');
        return;
      }
      const av = document.getElementById('profile-avatar-modal');
      const origContent = av.innerHTML;
      av.innerHTML = '<div style="font-size:10px;color:#fff;text-align:center;line-height:1.2">Uploading…</div>';
      try {
        const storageRef = ref(storage, `fc_avatars/${state.currentUser.uid}`);
        const snap = await uploadBytes(storageRef, file, { contentType: file.type });
        const url  = await getDownloadURL(snap.ref);
        await updateProfile(state.currentUser, { photoURL: url });
        await setDoc(doc(db, 'fc_users', state.currentUser.uid), { photoURL: url }, { merge: true });
        // Show new photo
        av.innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">`;
        // Update sidebar avatar
        const sideAvatar = document.getElementById('profile-avatar');
        if (sideAvatar) {
          sideAvatar.innerHTML = `<img src="${url}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">`;
        }
        showToast('Foto profil berhasil dipasang! 🎉');
      } catch (e) {
        av.innerHTML = origContent;
        showToast('Gagal upload foto. Coba lagi.');
      }
      picInput.value = '';
    });
  }

  document.getElementById('btn-save-profile').onclick = async () => {
    const name   = document.getElementById('edit-name').value.trim();
    const status = document.getElementById('edit-status').value.trim();
    const errEl  = document.getElementById('profile-error');
    errEl.classList.remove('show');
    if (!name || name.length < 2) {
      errEl.textContent = 'Nama minimal 2 karakter.';
      errEl.classList.add('show');
      return;
    }
    document.getElementById('btn-save-profile').disabled = true;
    try {
      await updateProfile(state.currentUser, { displayName: name });
      const statusSetAt = status ? new Date().toISOString() : null;
      await setDoc(doc(db, 'fc_users', state.currentUser.uid), { displayName: name, status, statusSetAt }, { merge: true });
      await setDoc(doc(db, 'fc_presence', state.currentUser.uid), { displayName: name }, { merge: true });
      state.userStatus = status;
      document.getElementById('profile-name').textContent     = name;
      document.getElementById('profile-avatar').textContent   = initials(name);
      closeModal('modal-profile');
      showToast('Profil berhasil diperbarui! ✨');
    } catch (e) {
      errEl.textContent = 'Gagal menyimpan.';
      errEl.classList.add('show');
    }
    document.getElementById('btn-save-profile').disabled = false;
  };
}

export async function signOut() {
  await setPresence(false);
  const { cleanupListeners } = await import('./app.js');
  cleanupListeners();
  await fbSignOut(auth);
  closeModal('modal-profile');
}
