// ── MESSAGES: LISTEN, RENDER, SEND ──
import {
  db, collection, doc, addDoc, deleteDoc, getDocs,
  onSnapshot, query, where, orderBy, serverTimestamp, Timestamp,
} from './config.js';
import { state } from './state.js';
import { hsl, initials, escapeHTML, resolvedName, getAlias } from './utils.js';
import { showToast } from './utils.js';
import { clearTyping } from './presence.js';

export function listenMessages(roomId) {
  if (state.messagesUnsub) state.messagesUnsub();
  state.messageTimers.forEach(t => clearTimeout(t));
  state.messageTimers.clear();

  const wrap = document.getElementById('messages-wrap');
  wrap.innerHTML = '';

  const now    = Timestamp.now();
  const cutoff = new Timestamp(now.seconds - 60, now.nanoseconds);

  const q = query(
    collection(db, 'fc_rooms', roomId, 'messages'),
    where('expiresAt', '>', cutoff),
    orderBy('expiresAt', 'asc')
  );

  state.messagesUnsub = onSnapshot(q, snap => {
    const nowMs = Date.now();
    snap.docChanges().forEach(change => {
      if (change.type === 'added') {
        const msg      = { id: change.doc.id, ...change.doc.data() };
        const expiresAt = msg.expiresAt?.toMillis?.() || (nowMs + 60000);
        const msLeft   = expiresAt - nowMs;
        if (msLeft <= 0) return;
        renderMessage(msg, msLeft);
        const fadeDelay = Math.max(0, msLeft - 10000);
        const t = setTimeout(() => {
          document.getElementById(`msg-${msg.id}`)?.classList.add('fading');
          setTimeout(() => {
            document.getElementById(`msg-${msg.id}`)?.remove();
            deleteDoc(doc(db, 'fc_rooms', roomId, 'messages', msg.id)).catch(() => {});
            checkEmpty();
          }, 10000);
        }, fadeDelay);
        state.messageTimers.set(msg.id, t);
      }
      if (change.type === 'removed') {
        document.getElementById(`msg-${change.doc.id}`)?.remove();
        checkEmpty();
      }
    });
    checkEmpty();
    scrollBottom();
    purgeExpiredMessages(roomId);
  });
}

export async function purgeExpiredMessages(roomId) {
  try {
    const now = Timestamp.now();
    const q   = query(collection(db, 'fc_rooms', roomId, 'messages'), where('expiresAt', '<=', now));
    const snap = await getDocs(q);
    snap.forEach(d => deleteDoc(d.ref).catch(() => {}));
  } catch (e) {}
}

export function renderMessage(msg, msLeft) {
  const wrap  = document.getElementById('messages-wrap');
  const empty = document.getElementById('empty-chat');
  if (empty) empty.remove();

  const isOwn       = msg.uid === state.currentUser.uid;
  const row         = document.createElement('div');
  row.className     = `msg-row${isOwn ? ' own' : ''}`;
  row.id            = `msg-${msg.id}`;

  const avatarColor = hsl(msg.uid || 'x');
  const displayName = resolvedName(msg.uid, msg.displayName);
  const theme       = state.currentRoomData?.nameTheme;
  const isAliased   = theme && theme !== 'none';
  const barDur      = Math.max(0, msLeft / 1000).toFixed(1);
  const timeStr     = msg.sentAt?.toDate
    ? msg.sentAt.toDate().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    : '';

  const photoURL = msg.photoURL || null;
  const avaInner = photoURL
    ? `<img src="${escapeHTML(photoURL)}" alt="" class="msg-avatar-img" referrerpolicy="no-referrer">`
    : initials(displayName);
  const ava = isOwn
    ? ''
    : `<div class="msg-avatar${photoURL ? ' has-photo' : ''}" style="background:linear-gradient(135deg,${avatarColor},#7c3aed)">${avaInner}</div>`;

  const senderLine = isAliased
    ? `<div class="msg-sender">${displayName} <span class="msg-alias">(${msg.displayName || 'Pengguna'})</span></div>`
    : `<div class="msg-sender">${displayName}</div>`;

  row.innerHTML = `
    ${ava}
    <div class="msg-content">
      ${!isOwn ? senderLine : ''}
      <div class="msg-bubble">${escapeHTML(msg.text)}</div>
      <div class="msg-timer-bar" style="animation-duration:${barDur}s"></div>
      <div class="msg-meta">
        <span>${timeStr}</span>
        <span class="ttl-badge"><span class="ttl-dot"></span>${Math.ceil(msLeft / 1000)}d</span>
      </div>
    </div>`;
  wrap.appendChild(row);
}

function checkEmpty() {
  const wrap    = document.getElementById('messages-wrap');
  const msgs    = wrap.querySelectorAll('.msg-row');
  const existing = document.getElementById('empty-chat');
  if (msgs.length === 0 && !existing) {
    const e       = document.createElement('div');
    e.className   = 'empty-chat';
    e.id          = 'empty-chat';
    e.innerHTML   = `
      <h3>Mulai Percakapan</h3>
      <p>Belum ada pesan di sini. Semua obrolan hangus otomatis dalam 60 detik.</p>`;
    wrap.appendChild(e);
    lucide.createIcons();
  } else if (msgs.length > 0 && existing) {
    existing.remove();
  }
}

function scrollBottom() {
  const wrap = document.getElementById('messages-wrap');
  wrap.scrollTop = wrap.scrollHeight;
}

export async function sendMessage() {
  if (!state.currentRoomId || !state.currentUser) return;
  const input = document.getElementById('msg-input');
  const text  = input.value.trim();
  if (!text) return;
  input.value = '';
  input.style.height = '';
  document.getElementById('btn-send').disabled = true;

  clearTimeout(state.typingTimeout);
  if (state.isTyping) { state.isTyping = false; clearTyping(); }

  const now      = Date.now();
  const expiresAt = new Timestamp(Math.floor((now + 60000) / 1000), 0);
  try {
    await addDoc(collection(db, 'fc_rooms', state.currentRoomId, 'messages'), {
      text,
      uid: state.currentUser.uid,
      displayName: state.currentUser.displayName || 'Pengguna',
      photoURL:    state.currentUser.photoURL || null,
      sentAt: serverTimestamp(),
      expiresAt,
    });
  } catch (e) {
    showToast('Gagal kirim pesan.');
  }
  setTimeout(() => { document.getElementById('btn-send').disabled = false; }, 300);
}

export function initMessageInput() {
  const input  = document.getElementById('msg-input');
  const sendBtn = document.getElementById('btn-send');

  sendBtn.onclick = sendMessage;

  input.oninput = function () {
    sendBtn.disabled = !this.value.trim();
    this.style.height = '';
    this.style.height = Math.min(this.scrollHeight, 140) + 'px';

    // Typing indicator
    import('./presence.js').then(({ setTyping, clearTyping }) => {
      if (state.currentRoomId && this.value.trim()) {
        if (!state.isTyping) {
          state.isTyping = true;
          setTyping(state.currentRoomId);
        }
        clearTimeout(state.typingTimeout);
        state.typingTimeout = setTimeout(() => {
          state.isTyping = false;
          clearTyping();
        }, 3000);
      } else {
        clearTimeout(state.typingTimeout);
        if (state.isTyping) { state.isTyping = false; clearTyping(); }
      }
    });
  };

  input.onkeydown = function (e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };
}
