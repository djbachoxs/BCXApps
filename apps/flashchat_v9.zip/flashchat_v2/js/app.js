// ── APP ENTRY POINT ──
// Bootstraps the app after Firebase auth resolves.
import {
  auth, db,
  onAuthStateChanged,
  doc, setDoc, getDoc,
  collection, query, where, addDoc, getDocs,
  serverTimestamp, updateDoc } from './config.js';
import { state } from './state.js';
import { initials, hsl, showToast } from './utils.js';
import { restoreTheme, syncThemeToggle, toggleTheme } from './theme.js';
import { initModalBackdrops, toggleSidebar, closeSidebar, openModal, closeModal } from './ui.js';
import { initAuthListeners, initSetNameListener, showRegister, showLogin } from './auth.js';
import { setPresence, listenPresence, listenTyping, clearTyping } from './presence.js';
import { listenRooms, openRoom, openCreateRoom, initCreateRoomListener } from './rooms.js';
import { initMessageInput } from './messages.js';
import {
  openMembersModal, filterMembersList,
  toggleRoomVisibility, setRoomTheme,
  leaveRoom, deleteRoom,
  clearInviteSearch, initInviteSearch,
} from './members.js';
import { openProfile, initProfileListeners, signOut } from './profile.js';

// ── Expose to HTML onclick attributes ──
window.showRegister       = showRegister;
window.showLogin          = showLogin;
window.openModal          = openModal;
window.closeModal         = closeModal;
window.toggleSidebar      = toggleSidebar;
window.closeSidebar       = closeSidebar;
window.toggleTheme        = toggleTheme;
window.openCreateRoom     = openCreateRoom;
window.openProfile        = openProfile;
window.signOut            = signOut;
window.filterMembersList  = filterMembersList;
window.toggleRoomVisibility = toggleRoomVisibility;
window.setRoomTheme       = setRoomTheme;
window.leaveRoom          = leaveRoom;
window.deleteRoom         = deleteRoom;
window.clearInviteSearch  = clearInviteSearch;

// ── Header member search ──
let _memberSearchTimer = null;
window.toggleMemberSearch = function() {
  const bar     = document.getElementById('header-member-search');
  const results = document.getElementById('header-search-results');
  const input   = document.getElementById('header-search-input');
  const isOpen  = bar.classList.contains('open');
  // Always keep display:flex so CSS transition works
  bar.style.display = 'flex';
  if (!isOpen) {
    bar.classList.add('open');
    setTimeout(() => input.focus(), 150);
  } else {
    bar.classList.remove('open');
    input.value = '';
    results.style.display = 'none';
    results.innerHTML = '';
    document.getElementById('header-search-clear').style.display = 'none';
  }
};

window.clearHeaderSearch = function() {
  const input   = document.getElementById('header-search-input');
  const results = document.getElementById('header-search-results');
  input.value = '';
  results.style.display = 'none';
  results.innerHTML = '';
  document.getElementById('header-search-clear').style.display = 'none';
  input.focus();
};

window.headerMemberSearch = async function(val) {
  const results  = document.getElementById('header-search-results');
  const clearBtn = document.getElementById('header-search-clear');
  clearBtn.style.display = val ? 'flex' : 'none';
  clearTimeout(_memberSearchTimer);
  if (!val.trim()) { results.style.display = 'none'; results.innerHTML = ''; return; }
  results.style.display = 'block';
  results.innerHTML = `<div class="header-search-hint">Mencari…</div>`;
  _memberSearchTimer = setTimeout(async () => {
    try {
      const { getDocs: _getDocs, collection: _col } = await import('./config.js');
      const snap = await _getDocs(_col(db, 'fc_users'));
      const kw   = val.toLowerCase();
      const hits = [];
      snap.forEach(d => {
        const data = d.data();
        const name = (data.displayName || '').toLowerCase();
        if (name.includes(kw)) hits.push({ uid: d.id, ...data });
      });
      results.innerHTML = '';
      if (!hits.length) {
        results.innerHTML = `<div class="header-search-hint">Tidak ditemukan.</div>`;
        return;
      }
      hits.forEach(u => {
        const { initials: _initials, hsl: _hsl } = { initials, hsl };
        const now   = Date.now();
        const setAt = u.statusSetAt ? new Date(u.statusSetAt).getTime() : 0;
        const status = (u.status && now - setAt < 86400000) ? u.status : '';
        const div = document.createElement('div');
        div.className = 'header-search-item';
        div.innerHTML = `
          <div class="avatar" style="width:32px;height:32px;font-size:12px;border-radius:9px;flex-shrink:0;background:linear-gradient(135deg,${hsl(u.uid)},#7c3aed)">${initials(u.displayName)}</div>
          <div class="header-search-item-info">
            <div class="header-search-item-name">${u.displayName || 'Pengguna'}</div>
            ${status ? `<div class="header-search-item-status">${status}</div>` : ''}
          </div>`;
        results.appendChild(div);
      });
    } catch (e) {
      results.innerHTML = `<div class="header-search-hint">Gagal memuat.</div>`;
    }
  }, 280);
};

// Close search when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('#header-member-search') &&
      !e.target.closest('#header-search-results') &&
      !e.target.closest('#btn-members')) {
    const bar     = document.getElementById('header-member-search');
    const results = document.getElementById('header-search-results');
    const input   = document.getElementById('header-search-input');
    if (bar && bar.classList.contains('open')) {
      bar.classList.remove('open');
      if (input) { input.value = ''; }
      if (results) { results.style.display = 'none'; results.innerHTML = ''; }
      const clr = document.getElementById('header-search-clear');
      if (clr) clr.style.display = 'none';
    }
  }
});

// Theme dropdown helpers
window.toggleThemeDropdown = function() {
  const dd   = document.getElementById('theme-dropdown');
  const btn  = document.getElementById('theme-select-btn');
  const wrap = document.getElementById('theme-select-wrap');
  const isOpen = dd.classList.contains('open');
  if (!isOpen) {
    // Position dropdown below the button
    const rect = btn.getBoundingClientRect();
    dd.style.top   = (rect.bottom + 6) + 'px';
    dd.style.left  = rect.left + 'px';
    dd.style.width = rect.width + 'px';
  }
  dd.classList.toggle('open', !isOpen);
  wrap.classList.toggle('open', !isOpen);
};
window.selectThemeOption = function(theme) {
  setRoomTheme(theme);
  const dd = document.getElementById('theme-dropdown');
  const wrap = document.getElementById('theme-select-wrap');
  dd.classList.remove('open');
  wrap.classList.remove('open');
  // Update button display
  const item = document.querySelector(`.theme-dropdown-item[data-theme="${theme}"]`);
  if (item) {
    const iconEl = document.getElementById('theme-select-icon');
    const labelEl = document.getElementById('theme-select-label');
    iconEl.innerHTML = item.querySelector('.theme-dd-icon').innerHTML;
    labelEl.textContent = item.querySelector('.theme-dd-name').textContent;
  }
};
// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('#theme-select-wrap')) {
    const dd = document.getElementById('theme-dropdown');
    const wrap = document.getElementById('theme-select-wrap');
    if (dd) dd.classList.remove('open');
    if (wrap) wrap.classList.remove('open');
  }
});

// ── Status Modal ──
window.openStatusModal = function(currentStatus = '') {
  const ta  = document.getElementById('status-textarea');
  const cnt = document.getElementById('status-char');
  ta.value  = currentStatus || '';
  cnt.textContent = ta.value.length;
  openModal('modal-status');
  setTimeout(() => ta.focus(), 150);
};

document.addEventListener('DOMContentLoaded', () => {
  const ta = document.getElementById('status-textarea');
  if (ta) {
    ta.addEventListener('input', () => {
      document.getElementById('status-char').textContent = ta.value.length;
    });
  }
});

window.applyStatusPreset = function(text) {
  const ta = document.getElementById('status-textarea');
  ta.value = text;
  document.getElementById('status-char').textContent = text.length;
  ta.focus();
};

window.saveStatus = async function() {
  const ta     = document.getElementById('status-textarea');
  const status = ta.value.trim();
  if (!state.currentUser) return;
  try {
    const { doc: fsDoc, setDoc: fsSetDoc } = await import('./config.js');
    await fsSetDoc(fsDoc(db, 'fc_users', state.currentUser.uid),
      { status, statusSetAt: status ? new Date().toISOString() : null },
      { merge: true });
    state.userStatus = status;
    closeModal('modal-status');
    showToast(status ? `Status diperbarui ✨` : 'Status dihapus');
  } catch (e) {
    showToast('Gagal menyimpan status.');
  }
};

window.clearStatus = async function() {
  if (!state.currentUser) return;
  try {
    const { doc: fsDoc, setDoc: fsSetDoc } = await import('./config.js');
    await fsSetDoc(fsDoc(db, 'fc_users', state.currentUser.uid),
      { status: '', statusSetAt: null }, { merge: true });
    state.userStatus = '';
    document.getElementById('status-textarea').value = '';
    document.getElementById('status-char').textContent = '0';
    closeModal('modal-status');
    showToast('Status dihapus');
  } catch (e) {
    showToast('Gagal menghapus status.');
  }
};

// ── Cleanup all Firestore listeners ──
export function cleanupListeners() {
  if (state.messagesUnsub)  state.messagesUnsub();
  if (state.roomsUnsub)     state.roomsUnsub();
  if (state.presenceUnsub)  state.presenceUnsub();
  if (state.typingUnsub)    state.typingUnsub();
  if (state.heartbeatInterval) clearInterval(state.heartbeatInterval);
  clearTimeout(state.typingTimeout);
  if (state.isTyping) clearTyping();
  state.messageTimers.forEach(t => clearTimeout(t));
  state.messageTimers.clear();
  state.currentRoomId   = null;
  state.currentRoomData = null;
}

// ── Main app init (called after successful auth) ──
export async function initApp(nameOverride) {
  const name = nameOverride || state.currentUser.displayName || 'Pengguna';

  document.getElementById('profile-name').textContent  = name;
  {
    const rawEmail = state.currentUser.email || '';
    const uname = rawEmail.endsWith('@flashchat.internal')
      ? '@' + rawEmail.replace('@flashchat.internal', '')
      : rawEmail;
    document.getElementById('profile-email').textContent = uname;
  }
  const av = document.getElementById('profile-avatar');
  av.style.background = `linear-gradient(135deg, ${hsl(state.currentUser.uid)}, #7c3aed)`;
  if (state.currentUser.photoURL) {
    av.innerHTML = `<img src="${state.currentUser.photoURL}" style="width:100%;height:100%;object-fit:cover;border-radius:inherit" onerror="this.parentElement.textContent='${initials(name)}'">`;
  } else {
    av.textContent = initials(name);
  }

  document.getElementById('edit-name').value = name;

  syncThemeToggle();
  await setPresence(true);

  state.heartbeatInterval = setInterval(() => setPresence(true), 30000);
  window.addEventListener('visibilitychange', () => {
    document.hidden ? setPresence(false) : setPresence(true);
  });
  window.addEventListener('beforeunload', () => setPresence(false));

  listenRooms();
  initInviteSearch();

  // Show search bar always (visible via CSS transition, not display toggle)
  const searchBar = document.getElementById('header-member-search');
  searchBar.style.display = 'flex';

  if (window.innerWidth <= 600) {
    const btn = document.getElementById('btn-menu-sidebar');
    btn.style.display = 'flex';
    lucide.createIcons();
  }
  document.getElementById('btn-menu-sidebar').onclick = toggleSidebar;
}

// ── Ensure default public rooms exist ──
async function ensureDefaultRooms() {
  const RENAME = { 'umum': 'aula', 'bebas': 'alun-alun' };
  for (const [oldName, newName] of Object.entries(RENAME)) {
    const qOld = query(collection(db, 'fc_rooms'), where('name', '==', oldName), where('type', '==', 'public'));
    const snapOld = await getDocs(qOld);
    for (const d of snapOld.docs) {
      try { await updateDoc(doc(db, 'fc_rooms', d.id), { name: newName }); } catch(e) {}
    }
  }
  const rooms = ['alun-alun', 'aula'];
  for (const name of rooms) {
    const q    = query(collection(db, 'fc_rooms'), where('name', '==', name), where('type', '==', 'public'));
    const snap = await getDocs(q);
    if (snap.empty) {
      await addDoc(collection(db, 'fc_rooms'), {
        name, type: 'public', createdBy: 'system', members: [], createdAt: serverTimestamp(),
      });
    }
  }
}

// ── Firebase Auth state observer ──
onAuthStateChanged(auth, async (user) => {
  document.getElementById('loading-screen').classList.add('hidden');

  if (!user) {
    document.getElementById('auth-overlay').classList.remove('hidden');
    document.getElementById('app').classList.remove('visible');
    document.getElementById('auth-login').style.display = '';
    document.getElementById('auth-register').style.display = 'none';
    document.getElementById('auth-setname').style.display = 'none';
    cleanupListeners();
    return;
  }

  state.currentUser = user;

  const userDoc    = await getDoc(doc(db, 'fc_users', user.uid));
  const storedName = userDoc.exists() ? userDoc.data().displayName : null;
  const displayName = user.displayName || storedName;
  // Load status into state (expire after 24h)
  if (userDoc.exists()) {
    const d = userDoc.data();
    const setAt = d.statusSetAt ? new Date(d.statusSetAt).getTime() : 0;
    if (d.status && Date.now() - setAt < 86400000) {
      state.userStatus = d.status;
    } else if (d.status) {
      // Expired — clear from server
      state.userStatus = '';
      import('./config.js').then(({ doc: fsDoc, setDoc: fsSetDoc }) => {
        fsSetDoc(fsDoc(db, 'fc_users', user.uid), { status: '', statusSetAt: null }, { merge: true }).catch(() => {});
      });
    }
  }

  if (!displayName) {
    document.getElementById('auth-overlay').classList.remove('hidden');
    document.getElementById('auth-login').style.display    = 'none';
    document.getElementById('auth-register').style.display = 'none';
    document.getElementById('auth-setname').style.display  = '';
    return;
  }

  if (!userDoc.exists()) {
    await setDoc(doc(db, 'fc_users', user.uid), {
      displayName, email: user.email, createdAt: serverTimestamp(),
    });
  }

  document.getElementById('auth-overlay').classList.add('hidden');
  document.getElementById('app').classList.add('visible');
  initApp(displayName);
  lucide.createIcons();
});

// ── Bootstrap ──
document.addEventListener('DOMContentLoaded', () => {
  restoreTheme();
  initModalBackdrops();
  initAuthListeners();
  initSetNameListener(initApp);
  initCreateRoomListener();
  initMessageInput();
  initProfileListeners();
  lucide.createIcons();
});

ensureDefaultRooms().catch(() => {});
