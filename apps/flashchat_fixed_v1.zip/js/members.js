// ── MEMBERS MODAL: VIEW, INVITE, VISIBILITY, NAME THEME, LEAVE/DELETE ──
import {
  db, collection, doc, getDocs, getDoc, updateDoc, deleteDoc,
} from './config.js';
import { state } from './state.js';
import { showToast, initials, hsl, getAlias } from './utils.js';
import { openModal, closeModal } from './ui.js';

export async function openMembersModal() {
  const room     = state.currentRoomData;
  const isCreator = room.createdBy === state.currentUser.uid;
  const isPrivate = room.type === 'private';
  const isMember  = (room.members || []).includes(state.currentUser.uid);

  document.getElementById('modal-members-room-name').textContent = room.name;
  document.getElementById('invite-error').classList.remove('show');
  document.getElementById('invite-section').style.display = isCreator ? '' : 'none';

  if (isCreator) {
    const toggle = document.getElementById('visibility-toggle');
    toggle.checked = isPrivate;
    updateVisibilityUI(isPrivate);
    updateThemeUI(room.nameTheme || 'none');
  }

  document.getElementById('btn-delete-room').style.display = isCreator ? '' : 'none';
  document.getElementById('btn-leave-room').style.display  = (isPrivate && !isCreator && isMember) ? '' : 'none';

  // Reset cache & search fields
  state.cachedMembersData = [];
  const memberSearch = document.getElementById('member-search-input');
  if (memberSearch) memberSearch.value = '';
  const searchInput = document.getElementById('invite-search');
  if (searchInput) searchInput.value = '';
  document.getElementById('invite-results').innerHTML = '';
  document.getElementById('invite-search-clear').style.display = 'none';

  document.getElementById('members-list').innerHTML =
    '<div style="font-size:13px;color:var(--text-muted);padding:8px 0">Memuat…</div>';
  openModal('modal-members');
  lucide.createIcons();
  await renderMembersList();
}

export async function renderMembersList(filterQuery = '') {
  const room        = state.currentRoomData;
  const membersList = document.getElementById('members-list');
  const members     = room.members || [];

  if (state.cachedMembersData.length === 0 || filterQuery === '__reload__') {
    membersList.innerHTML = '<div style="font-size:13px;color:var(--text-muted);padding:8px 0">Memuat…</div>';
    state.cachedMembersData = [];
    for (const uid of members) {
      try {
        const uDoc  = await getDoc(doc(db, 'fc_users', uid));
        const uData = uDoc.exists() ? uDoc.data() : { displayName: 'Pengguna', email: '' };
        state.cachedMembersData.push({ uid, ...uData });
      } catch (e) {}
    }
    filterQuery = '';
  }

  const kw       = filterQuery.toLowerCase().trim();
  const filtered = kw
    ? state.cachedMembersData.filter(u =>
        (u.displayName || '').toLowerCase().includes(kw) ||
        (u.email || '').toLowerCase().includes(kw))
    : state.cachedMembersData;

  membersList.innerHTML = '';
  if (filtered.length === 0) {
    membersList.innerHTML = `<div style="font-size:13px;color:var(--text-muted);padding:8px 0">${kw ? 'Anggota tidak ditemukan.' : 'Belum ada anggota'}</div>`;
    return;
  }

  filtered.forEach(uData => {
    const alias        = getAlias(uData.uid, state.currentRoomData?.nameTheme);
    const displayLabel = alias
      ? `${alias} <span style="font-size:11px;color:var(--text-muted);font-style:italic">(${uData.displayName})</span>`
      : uData.displayName;
    const avatarText   = initials(alias || uData.displayName);
    const div          = document.createElement('div');
    div.className      = 'member-item';
    div.innerHTML      = `
      <div class="avatar" style="background:linear-gradient(135deg,${hsl(uData.uid)},#7c3aed)">${avatarText}</div>
      <div>
        <div style="font-size:14px;font-weight:500;color:var(--text-primary)">${displayLabel}</div>
        <div style="font-size:12px;color:var(--text-muted)">${uData.email}</div>
      </div>
      <div class="member-role">${uData.uid === room.createdBy ? 'Pembuat' : 'Anggota'}</div>`;
    membersList.appendChild(div);
  });
}

export function filterMembersList(val) {
  renderMembersList(val);
}

// ── Visibility toggle ──
function updateVisibilityUI(isPrivate) {
  document.getElementById('visibility-label').textContent = isPrivate ? 'Privat' : 'Terbuka';
  document.getElementById('visibility-desc').textContent  = isPrivate
    ? 'Hanya anggota yang diundang dapat bergabung'
    : 'Semua anggota bisa melihat dan bergabung';
  const iconEl = document.getElementById('visibility-icon-el');
  if (iconEl) iconEl.setAttribute('data-lucide', isPrivate ? 'lock' : 'eye');
  lucide.createIcons();
}

export async function toggleRoomVisibility(checkbox) {
  if (!state.currentRoomData || !state.currentUser) return;
  const isPrivate = checkbox.checked;
  const newType   = isPrivate ? 'private' : 'public';
  checkbox.disabled = true;
  try {
    await updateDoc(doc(db, 'fc_rooms', state.currentRoomData.id), { type: newType });
    state.currentRoomData.type = newType;
    updateVisibilityUI(isPrivate);
    document.getElementById('header-room-name').textContent =
      (newType === 'private' ? '🔒 ' : '# ') + state.currentRoomData.name;
    showToast(`Room diubah ke ${isPrivate ? 'Privat 🔒' : 'Terbuka 🌐'}`);
  } catch (e) {
    checkbox.checked = !isPrivate;
    showToast('Gagal mengubah visibilitas.');
  }
  checkbox.disabled = false;
}

// ── Name theme ──
function updateThemeUI(theme) {
  // Sync dropdown check marks
  document.querySelectorAll('.theme-dropdown-item').forEach(el => {
    el.classList.toggle('active', el.dataset.theme === theme);
  });
  // Sync dropdown button
  const activeItem = document.querySelector(`.theme-dropdown-item[data-theme="${theme}"]`);
  if (activeItem) {
    const iconEl = document.getElementById('theme-select-icon');
    const labelEl = document.getElementById('theme-select-label');
    if (iconEl) iconEl.innerHTML = activeItem.querySelector('.theme-dd-icon').innerHTML;
    if (labelEl) labelEl.textContent = activeItem.querySelector('.theme-dd-name').textContent;
  }
  const preview = document.getElementById('theme-alias-preview');
  if (!preview) return;
  if (!theme || theme === 'none') {
    preview.innerHTML = 'Nama tampil seperti biasa';
  } else {
    const myAlias = getAlias(state.currentUser.uid, theme);
    const emoji   = { hewan:'🦊', tokoh:'🌍', pohon:'🌳', buah:'🍎', planet:'🪐', majapahit:'♛' }[theme] || '✨';
    preview.innerHTML = `Namamu tampil sebagai ${emoji} <span>${myAlias}</span>`;
  }
}

export async function setRoomTheme(theme) {
  if (!state.currentRoomData || !state.currentUser) return;
  if (state.currentRoomData.createdBy !== state.currentUser.uid) return;
  try {
    await updateDoc(doc(db, 'fc_rooms', state.currentRoomData.id), { nameTheme: theme });
    state.currentRoomData.nameTheme = theme;
    updateThemeUI(theme);
    state.cachedMembersData = [];
    await renderMembersList();
    const label = theme === 'none' ? 'Nama asli' : theme.charAt(0).toUpperCase() + theme.slice(1);
    showToast(`Tema nama: ${label} ✨`);
  } catch (e) {
    showToast('Gagal mengubah tema.');
  }
}

// ── Leave room ──
export async function leaveRoom() {
  if (!state.currentRoomData || !state.currentUser) return;
  const room = state.currentRoomData;
  if (!confirm(`Keluar dari room "${room.name}"?`)) return;
  try {
    const newMembers = (room.members || []).filter(uid => uid !== state.currentUser.uid);
    await updateDoc(doc(db, 'fc_rooms', room.id), { members: newMembers });
    closeModal('modal-members');
    state.currentRoomId   = null;
    state.currentRoomData = null;
    showToast(`Kamu telah keluar dari room "${room.name}".`);
  } catch (e) {
    showToast('Gagal keluar dari room.');
  }
}

// ── Delete room (creator only) ──
export async function deleteRoom() {
  if (!state.currentRoomData || !state.currentUser) return;
  const room = state.currentRoomData;
  if (room.createdBy !== state.currentUser.uid) {
    showToast('Hanya kreator yang bisa menghapus room.');
    return;
  }
  if (!confirm(`Hapus room "${room.name}" secara permanen? Semua pesan akan hilang.`)) return;
  try {
    const msgSnap = await getDocs(collection(db, 'fc_rooms', room.id, 'messages'));
    for (const d of msgSnap.docs) await deleteDoc(d.ref).catch(() => {});
    await deleteDoc(doc(db, 'fc_rooms', room.id));
    closeModal('modal-members');
    state.currentRoomId   = null;
    state.currentRoomData = null;
    showToast(`Room "${room.name}" telah dihapus.`);
  } catch (e) {
    showToast('Gagal menghapus room.');
  }
}

// ── Invite user search ──
let inviteSearchTimer = null;

export function clearInviteSearch() {
  document.getElementById('invite-search').value = '';
  document.getElementById('invite-results').innerHTML = '';
  document.getElementById('invite-search-clear').style.display = 'none';
}

export function initInviteSearch() {
  const searchInput = document.getElementById('invite-search');
  if (!searchInput || searchInput._listenerAdded) return;
  searchInput._listenerAdded = true;
  searchInput.addEventListener('input', () => {
    const q = searchInput.value.trim();
    document.getElementById('invite-search-clear').style.display = q ? '' : 'none';
    clearTimeout(inviteSearchTimer);
    if (!q) { document.getElementById('invite-results').innerHTML = ''; return; }
    inviteSearchTimer = setTimeout(() => searchUsers(q), 280);
  });
}

async function searchUsers(keyword) {
  const resultsEl = document.getElementById('invite-results');
  resultsEl.innerHTML = `<div class="invite-result-hint">Mencari…</div>`;
  const kw = keyword.toLowerCase();
  try {
    const snap           = await getDocs(collection(db, 'fc_users'));
    const currentMembers = state.currentRoomData.members || [];
    const matches        = [];
    snap.forEach(d => {
      if (d.id === state.currentUser.uid) return;
      const data  = d.data();
      const name  = (data.displayName || '').toLowerCase();
      const email = (data.email || '').toLowerCase();
      if (name.includes(kw) || email.includes(kw)) matches.push({ uid: d.id, ...data });
    });

    resultsEl.innerHTML = '';
    if (matches.length === 0) {
      resultsEl.innerHTML = `<div class="invite-result-hint">Tidak ada pengguna ditemukan.</div>`;
      return;
    }

    matches.forEach(user => {
      const isMember = currentMembers.includes(user.uid);
      const div      = document.createElement('div');
      div.className  = 'invite-result-item';
      div.innerHTML  = `
        <div class="avatar" style="width:32px;height:32px;font-size:12px;border-radius:8px;background:linear-gradient(135deg,${hsl(user.uid)},#7c3aed)">${initials(user.displayName)}</div>
        <div class="invite-result-info">
          <div class="invite-result-name">${user.displayName || 'Pengguna'}</div>
          <div class="invite-result-email">${user.email || ''}</div>
        </div>
        <button class="btn-add-user${isMember ? ' added' : ''}" data-uid="${user.uid}" ${isMember ? 'disabled' : ''}>
          ${isMember ? '✓ Anggota' : '+ Tambah'}
        </button>`;
      div.querySelector('.btn-add-user').onclick = async (e) => {
        if (isMember) return;
        const btn   = e.currentTarget;
        btn.disabled = true;
        btn.textContent = '…';
        try {
          const members = state.currentRoomData.members || [];
          await updateDoc(doc(db, 'fc_rooms', state.currentRoomId), { members: [...members, user.uid] });
          btn.textContent = '✓ Anggota';
          btn.classList.add('added');
          showToast(`${user.displayName} ditambahkan ke room! 🎉`);
          state.cachedMembersData = [];
          await renderMembersList();
        } catch (err) {
          btn.disabled    = false;
          btn.textContent = '+ Tambah';
          showToast('Gagal menambahkan anggota.');
        }
      };
      resultsEl.appendChild(div);
    });
  } catch (e) {
    resultsEl.innerHTML = `<div class="invite-result-hint">Gagal memuat pengguna.</div>`;
  }
}
