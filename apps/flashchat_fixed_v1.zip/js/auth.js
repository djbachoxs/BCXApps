// ── AUTH FLOW ──
import {
  auth, db,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  doc, setDoc, getDoc, getDocs, collection, query, where, serverTimestamp,
} from './config.js';
import { state } from './state.js';
import { friendlyError } from './utils.js';

// ── Password strength validator ──
function validatePassword(pass) {
  const errors = [];
  if (pass.length < 8)          errors.push('minimal 8 karakter');
  if (!/[A-Z]/.test(pass))      errors.push('minimal 1 huruf besar (A-Z)');
  if (!/[a-z]/.test(pass))      errors.push('minimal 1 huruf kecil (a-z)');
  if (!/[0-9]/.test(pass))      errors.push('minimal 1 angka (0-9)');
  return errors;
}

// ── Username to fake email (Firebase needs email format) ──
function usernameToEmail(username) {
  return username.toLowerCase().trim() + '@flashchat.internal';
}

// ── Look up username in Firestore → return uid or null ──
async function resolveUsername(username) {
  const q = query(
    collection(db, 'fc_users'),
    where('username', '==', username.toLowerCase().trim())
  );
  const snap = await getDocs(q);
  if (snap.empty) return null;
  return { uid: snap.docs[0].id, ...snap.docs[0].data() };
}

// ── Toggle password visibility ──
function togglePasswordVisibility(inputId, iconId) {
  const input = document.getElementById(inputId);
  const icon  = document.getElementById(iconId);
  if (!input) return;
  if (input.type === 'password') {
    input.type = 'text';
    if (icon) icon.setAttribute('data-lucide', 'eye-off');
  } else {
    input.type = 'password';
    if (icon) icon.setAttribute('data-lucide', 'eye');
  }
  if (window.lucide) lucide.createIcons();
}
window.togglePasswordVisibility = togglePasswordVisibility;

export function showRegister() {
  document.getElementById('auth-login').style.display    = 'none';
  document.getElementById('auth-register').style.display = '';
}

export function showLogin() {
  document.getElementById('auth-register').style.display = 'none';
  document.getElementById('auth-login').style.display    = '';
}

export function initAuthListeners() {
  // ── LOGIN ──
  document.getElementById('btn-login').onclick = async () => {
    const username = document.getElementById('login-username').value.trim();
    const pass     = document.getElementById('login-pass').value;
    const errEl    = document.getElementById('login-error');
    errEl.classList.remove('show');

    if (!username || !pass) {
      errEl.textContent = 'Isi semua kolom.';
      errEl.classList.add('show');
      return;
    }

    const btn = document.getElementById('btn-login');
    btn.disabled = true;
    btn.textContent = 'Memeriksa…';

    try {
      // Look up username → fake email
      const userData = await resolveUsername(username);
      if (!userData) {
        errEl.textContent = 'Username tidak ditemukan.';
        errEl.classList.add('show');
        btn.disabled = false;
        btn.textContent = 'Masuk ke FlashChat';
        return;
      }
      const fakeEmail = usernameToEmail(username);
      await signInWithEmailAndPassword(auth, fakeEmail, pass);
    } catch (e) {
      errEl.textContent = e.code === 'auth/wrong-password' || e.code === 'auth/invalid-credential'
        ? 'Password salah. Coba lagi.'
        : friendlyError(e.code);
      errEl.classList.add('show');
      btn.disabled = false;
      btn.textContent = 'Masuk ke FlashChat';
    }
  };

  // ── REGISTER ──
  document.getElementById('btn-register').onclick = async () => {
    const username  = document.getElementById('reg-username').value.trim();
    const pass      = document.getElementById('reg-pass').value;
    const passConf  = document.getElementById('reg-pass-confirm').value;
    const name      = document.getElementById('reg-name').value.trim();
    const errEl     = document.getElementById('reg-error');
    errEl.classList.remove('show');

    // Basic empty check
    if (!username || !pass || !passConf || !name) {
      errEl.textContent = 'Semua kolom wajib diisi.';
      errEl.classList.add('show');
      return;
    }

    // Username format
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      errEl.textContent = 'Username hanya boleh huruf, angka, dan underscore. 3-20 karakter.';
      errEl.classList.add('show');
      return;
    }

    // Display name
    if (name.length < 2) {
      errEl.textContent = 'Nama tampilan minimal 2 karakter.';
      errEl.classList.add('show');
      return;
    }

    // Password strength
    const passErrors = validatePassword(pass);
    if (passErrors.length > 0) {
      errEl.textContent = 'Password harus: ' + passErrors.join(', ') + '.';
      errEl.classList.add('show');
      return;
    }

    // Confirm password
    if (pass !== passConf) {
      errEl.textContent = 'Konfirmasi password tidak cocok.';
      errEl.classList.add('show');
      return;
    }

    const btn = document.getElementById('btn-register');
    btn.disabled = true;
    btn.textContent = 'Membuat akun…';

    try {
      // Check username availability
      const existing = await resolveUsername(username);
      if (existing) {
        errEl.textContent = 'Username sudah dipakai. Coba yang lain.';
        errEl.classList.add('show');
        btn.disabled = false;
        btn.textContent = 'Buat Akun';
        return;
      }

      const fakeEmail = usernameToEmail(username);
      const cred = await createUserWithEmailAndPassword(auth, fakeEmail, pass);
      await updateProfile(cred.user, { displayName: name });
      await setDoc(doc(db, 'fc_users', cred.user.uid), {
        username:    username.toLowerCase().trim(),
        displayName: name,
        email:       fakeEmail,
        createdAt:   serverTimestamp(),
      });
    } catch (e) {
      errEl.textContent = e.code === 'auth/email-already-in-use'
        ? 'Username sudah dipakai. Coba yang lain.'
        : friendlyError(e.code);
      errEl.classList.add('show');
      btn.disabled = false;
      btn.textContent = 'Buat Akun';
    }
  };
}

// Set display name step (kept for compatibility — no longer triggered by Google)
export function initSetNameListener(initApp) {
  const btn = document.getElementById('btn-setname');
  if (!btn) return;
  btn.onclick = async () => {
    const name  = document.getElementById('setname-input').value.trim();
    const errEl = document.getElementById('setname-error');
    errEl.classList.remove('show');
    if (!name || name.length < 2) {
      errEl.textContent = 'Nama minimal 2 karakter.';
      errEl.classList.add('show');
      return;
    }
    btn.disabled = true;
    try {
      await updateProfile(state.currentUser, { displayName: name });
      await setDoc(doc(db, 'fc_users', state.currentUser.uid), {
        displayName: name, email: state.currentUser.email, createdAt: serverTimestamp(),
      }, { merge: true });
      document.getElementById('auth-overlay').classList.add('hidden');
      initApp();
    } catch (e) {
      errEl.textContent = 'Gagal menyimpan nama.';
      errEl.classList.add('show');
      btn.disabled = false;
    }
  };
}
