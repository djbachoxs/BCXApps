// ── SHARED MUTABLE STATE ──
// All modules import this object and mutate its properties directly.
// Because ES modules share the same object reference, mutations are visible
// to every importer.

export const state = {
  currentUser:      null,
  currentRoomId:    null,
  currentRoomData:  null,

  // Firestore unsubscribers
  messagesUnsub:    null,
  roomsUnsub:       null,
  presenceUnsub:    null,
  typingUnsub:      null,

  heartbeatInterval: null,
  messageTimers:    new Map(),
  cachedMembersData: [],

  // Typing state
  typingTimeout:    null,
  isTyping:         false,

  // User profile extras
  userStatus:       '',
};
