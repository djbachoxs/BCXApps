// ── ROOMS: LIST, OPEN, CREATE ──
import {
  db, collection, doc, addDoc, deleteDoc, getDocs,
  onSnapshot, query, where, serverTimestamp, getDoc,
} from './config.js';
import { state } from './state.js';
import { showToast } from './utils.js';
import { openModal, closeModal } from './ui.js';
import { listenMessages } from './messages.js';
import { listenPresence, listenTyping } from './presence.js';

export function listenRooms() {
  if (state.roomsUnsub) state.roomsUnsub();
  const q = collection(db, 'fc_rooms');
  state.roomsUnsub = onSnapshot(q, snap => {
    const roomList   = document.getElementById('room-list');
    roomList.innerHTML = '';
    let firstPublic  = null;

    snap.forEach(d => {
      const room = { id: d.id, ...d.data() };
      if (room.type === 'private') {
        const members = room.members || [];
        if (!members.includes(state.currentUser.uid)) return;
      }
      if (!firstPublic && room.type === 'public') firstPublic = room;

      const wrap   = document.createElement('div');
      wrap.className = 'room-item-wrap';

      const roomEl = document.createElement('div');
      roomEl.className = `room-item${state.currentRoomId === d.id ? ' active' : ''}`;
      roomEl.dataset.roomId = d.id;
      roomEl.innerHTML = `
        <span class="room-icon">${room.type === 'private' ? '🔒' : '#'}</span>
        <span class="room-name">${room.name}</span>`;
      roomEl.onclick = () => { openRoom(room); };
      wrap.appendChild(roomEl);

      // Settings button for custom rooms (non-system, user is member or creator)
      if (room.createdBy !== 'system') {
        const settingsBtn     = document.createElement('div');
        settingsBtn.className = 'room-settings-btn';
        settingsBtn.title     = 'Pengaturan room';
        settingsBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`;
        settingsBtn.onclick   = async (e) => {
          e.stopPropagation();
          // Make sure the room is loaded as current before opening modal
          if (state.currentRoomId !== room.id) {
            await openRoom(room);
          }
          const { openMembersModal } = await import('./members.js');
          openMembersModal();
        };
        wrap.appendChild(settingsBtn);
      }

      // Delete button (creator only, non-system)
      if (room.createdBy === state.currentUser.uid && room.createdBy !== 'system') {
        const delBtn      = document.createElement('div');
        delBtn.className  = 'room-delete-btn';
        delBtn.title      = 'Hapus room';
        delBtn.innerHTML  = `<i data-lucide="x"></i>`;
        delBtn.onclick    = (e) => {
          e.stopPropagation();
          openDeleteConfirm(room);
        };
        wrap.appendChild(delBtn);
      }

      roomList.appendChild(wrap);
    });

    if (!state.currentRoomId && firstPublic) openRoom(firstPublic);
    lucide.createIcons();
    listenPresence();
  });
}

export async function openRoom(room) {
  if (state.currentRoomId && state.currentRoomId !== room.id) {
    const { clearTyping } = await import('./presence.js');
    clearTyping();
  }

  state.currentRoomId   = room.id;
  state.currentRoomData = room;

  // Fetch latest room data (nameTheme etc.)
  try {
    const snap = await getDoc(doc(db, 'fc_rooms', room.id));
    if (snap.exists()) state.currentRoomData = { id: snap.id, ...snap.data() };
  } catch (e) {}

  document.getElementById('header-room-name').textContent =
    (state.currentRoomData.type === 'private' ? '🔒 ' : '# ') + state.currentRoomData.name;

  document.querySelectorAll('.room-item').forEach(el => {
    el.classList.toggle('active', el.dataset.roomId === room.id);
  });

  listenTyping(room.id);
  listenMessages(room.id);
}

// ── Create Room ──
export async function openCreateRoom() {
  document.getElementById('new-room-name').value = '';
  document.getElementById('create-room-error').classList.remove('show');

  const q     = query(collection(db, 'fc_rooms'), where('createdBy', '==', state.currentUser.uid));
  const snap  = await getDocs(q);
  const count = snap.size;
  const isFull = count >= 4;

  const countEl = document.getElementById('quota-count');
  const fillEl  = document.getElementById('quota-fill');
  countEl.textContent = `${count} / 4`;
  countEl.classList.toggle('full', isFull);
  fillEl.style.width = `${Math.min((count / 4) * 100, 100)}%`;
  fillEl.classList.toggle('full', isFull);

  const btn        = document.getElementById('btn-do-create-room');
  const nameInput  = document.getElementById('new-room-name');
  const typeSelect = document.getElementById('new-room-type');
  btn.disabled        = isFull;
  nameInput.disabled  = isFull;
  typeSelect.disabled = isFull;

  if (isFull) {
    const errEl = document.getElementById('create-room-error');
    errEl.textContent = 'Kamu sudah membuat 4 room (batas maksimum). Hapus room lama untuk membuat yang baru.';
    errEl.classList.add('show');
  } else {
    document.getElementById('create-room-error').classList.remove('show');
  }

  openModal('modal-create-room');
  lucide.createIcons();
}

export function initCreateRoomListener() {
  document.getElementById('btn-do-create-room').onclick = async () => {
    const name  = document.getElementById('new-room-name').value.trim();
    const type  = document.getElementById('new-room-type').value;
    const errEl = document.getElementById('create-room-error');
    errEl.classList.remove('show');

    if (!name) {
      errEl.textContent = 'Nama room wajib diisi.';
      errEl.classList.add('show');
      return;
    }

    // Double-check quota
    const qCheck    = query(collection(db, 'fc_rooms'), where('createdBy', '==', state.currentUser.uid));
    const snapCheck = await getDocs(qCheck);
    if (snapCheck.size >= 4) {
      errEl.textContent = 'Batas 4 room tercapai. Hapus room lama terlebih dahulu.';
      errEl.classList.add('show');
      return;
    }

    document.getElementById('btn-do-create-room').disabled = true;
    try {
      await addDoc(collection(db, 'fc_rooms'), {
        name, type,
        createdBy: state.currentUser.uid,
        members: [state.currentUser.uid],
        createdAt: serverTimestamp(),
      });
      closeModal('modal-create-room');
      showToast(`Room "${name}" berhasil dibuat! 🎉`);
    } catch (e) {
      errEl.textContent = 'Gagal membuat room.';
      errEl.classList.add('show');
    }
    document.getElementById('btn-do-create-room').disabled = false;
  };
}

// ── Delete Room Confirmation Modal ──
function openDeleteConfirm(room) {
  const msgEl = document.getElementById('modal-confirm-delete-msg');
  msgEl.textContent = `Yakin ingin menghapus room "${room.name}"?`;

  openModal('modal-confirm-delete');
  lucide.createIcons();

  const btn = document.getElementById('btn-confirm-delete-room');
  // Remove previous listeners by cloning
  const newBtn = btn.cloneNode(true);
  btn.parentNode.replaceChild(newBtn, btn);

  newBtn.onclick = async () => {
    newBtn.disabled = true;
    try {
      const msgSnap = await getDocs(collection(db, 'fc_rooms', room.id, 'messages'));
      for (const md of msgSnap.docs) await deleteDoc(md.ref).catch(() => {});
      await deleteDoc(doc(db, 'fc_rooms', room.id));
      if (state.currentRoomId === room.id) {
        state.currentRoomId   = null;
        state.currentRoomData = null;
      }
      closeDeleteConfirm();
      showToast(`Room "${room.name}" dihapus.`);
    } catch (err) {
      showToast('Gagal menghapus room.');
      newBtn.disabled = false;
    }
  };
}

function closeDeleteConfirm() {
  closeModal('modal-confirm-delete');
}

// Expose globally for inline onclick in HTML
window.closeDeleteConfirm = closeDeleteConfirm;
