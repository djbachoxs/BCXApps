// ── FIREBASE CONFIG & INIT ──
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import { getStorage } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js';

import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut as fbSignOut,
  GoogleAuthProvider,
  signInWithPopup,
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';

import {
  getFirestore,
  collection,
  doc,
  addDoc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp,
} from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: "AIzaSyDpRvM-kzGDSl0c4Qj1srnVf6CqeFMfATA",
  authDomain: "tapchat-builder.firebaseapp.com",
  projectId: "tapchat-builder",
  storageBucket: "tapchat-builder.firebasestorage.app",
  messagingSenderId: "753773448817",
  appId: "1:753773448817:web:dad73083e70c39766e95d0",
  measurementId: "G-G3MCCL9STF",
};

const app = initializeApp(firebaseConfig, 'flashchat');
export const auth = getAuth(app);
export const db      = getFirestore(app);
export const storage = getStorage(app);

// Re-export Firebase functions so other modules don't need CDN URLs
export {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  fbSignOut,
  GoogleAuthProvider,
  signInWithPopup,
  collection, doc, addDoc, setDoc, getDoc, getDocs,
  updateDoc, deleteDoc, onSnapshot, query, where, orderBy,
  serverTimestamp, Timestamp,
};
